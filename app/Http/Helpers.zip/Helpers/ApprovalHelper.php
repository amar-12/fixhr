<?php

namespace App\Helpers;

use App\Http\Requests\Approval\AdvanceLogRequest;
use App\Mail\ApprovalMail;
use App\Models\ActionUponRejection;
use App\Models\AdvanceLog;
use App\Models\ApprovalLog;
use App\Models\ApprovalModule;
use App\Models\AttendanceException;
use App\Models\Employee;
use App\Models\GatePass;
use App\Models\LeaveRequest;
use App\Models\LoanRequest;
use App\Models\ProcessApprover;
use App\Models\TadaClaim;
use App\Models\TadaRequestPlan;
use Exception;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\ExpressionLanguage\ExpressionLanguage;
use App\Helpers\CentralLogics;
use App\Models\AttendanceRecord;
use App\Models\EmployeeApprovalMapping;
use App\Models\EmployeeApprovalStatus;
use App\Models\MasterTable;
use Carbon\Carbon;
use App\Models\DeductionLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class ApprovalHelper
{
    public static function checkRuleCriteriaModule($isPlan, $exeTypeId, $travelType = 124, $trpId = 0, $amId = 0, $statusId = 140, $trpAdvanceAllowance = 0, $plan = null)
    {
        $user = Auth::user();
        try {
            if ($isPlan) {
                if ($plan->fh_policy_tada_travel_type->pttt_approval_type_id == 198) {
                    $approvalModule = ApprovalModule::with([
                        'fh_rule_criteria' => ['fh_approval_rule:m_id,m_name', 'fh_rule_condition:m_id,m_name', 'fh_condition_option:m_id,m_name'],
                        'fh_process_approvers' => [
                            'fh_employee:emp_id,emp_fname,emp_email,emp_fname'
                        ]
                    ])->where(['am_b_id' => $user->emp_b_id, 'am_id' => $amId, 'am_status' => 1])->first();
                    if ($approvalModule) {
                        if (in_array($exeTypeId, json_decode($approvalModule->am_exe_on))) {
                            $ruleMatched = self::checkRuleCriteria($statusId, $trpAdvanceAllowance, $approvalModule->fh_rule_criteria);
                            if ($ruleMatched) {
                                foreach ($approvalModule->fh_process_approvers as $approval) {
                                    if ($approval->fh_employee()->exists()) {
                                        // $mailData = [
                                        //     'subject' => 'Tour Request Approval',
                                        //     'url' => route('travel.request.show', ['id' => md5($plan->trp_id)]),
                                        //     'mail_type' => 'TOUR_APPROVAL_REQUEST',
                                        //     'data' => ['planData' => $plan, 'nextApproverName' => $approval->fh_employee->emp_fname],
                                        // ];

                                        if ($approval->pa_type == 'single' || $approval->pa_type == 'anyone' || ($approval->pa_type == 'and' && $approval->pa_sequence == 1)) {
                                            $placeholders = [
                                                '{travel_type}' =>  $plan->fh_policy_tada_travel_type->fh_travel_type->m_name,
                                                '{receiver_name}' => $approval->fh_employee->emp_full_name,
                                                '{request_id}'  => $plan->trp_unique_id,
                                                '{submit_date}' => Carbon::parse($plan->created_at)->format('d M, Y'),
                                                '{start_time}' =>  Carbon::parse($plan->trd_start_time)->format('h:i A'),
                                                '{end_date}' =>  Carbon::parse($plan->trp_end_date)->format('d M, Y'),
                                                '{end_time}' =>  Carbon::parse($plan->trd_end_time)->format('h:i A'),
                                                '{destination}' => $plan->trp_destination,
                                                '{travel_purpose}' => $plan->fh_travel_purpose->tp_name,
                                                '{employee_name}' => $plan->fh_employee->emp_full_name ?? 'N/A',
                                                '{employee_code}' => $plan->fh_employee->emp_code ?? 'N/A',
                                                '{employee_designation}' => $plan->fh_employee->fh_designation->dg_name ?? 'N/A',
                                                '{employee_phone}' => $plan->fh_employee->emp_phone ?? 'N/A',
                                            ];
                                            // The recipient's email address
                                            $recipientEmail = $approval->fh_employee->emp_email;
                                            // The email template type and business ID
                                            $templateType = 406; // Replace with your mail template type
                                            $businessId = $user->emp_b_id; // Replace with your business ID if applicable
                                            // Sending the email using the CentralLogics class
                                            $sent = CentralLogics::sendCustomEmail($templateType, $placeholders, $recipientEmail, $businessId);

                                            // CentralLogics::send_mail($approval->fh_employee->emp_email, new ApprovalMail($mailData));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            return 'Error: ' . $e->getMessage();
        }
    }

    public static function checkRuleCriteria($statusId, $trpAdvanceAllowance, $rules)
    {

        try {
            $ruleMatched = false;
            foreach ($rules as $rule) {
                $ruleValue = isset($rule->fh_condition_option->m_id) ? $rule->fh_condition_option->m_id : $rule->rc_custom_value;

                switch ($rule->fh_approval_rule->m_id) {
                    case 131: //group=>APPROVAL_RULE, name=Request Status
                        $condition = $rule->fh_rule_condition->m_name;
                        if (
                            ($condition == "IS" && $statusId == $ruleValue) ||
                            ($condition == "IS NOT" && $statusId != $ruleValue)
                        ) {
                            $ruleMatched = true;
                        }
                        break;

                    case 132: //group=>APPROVAL_RULE, name=Advance
                        $expressionLanguage = new ExpressionLanguage();
                        $expression = $trpAdvanceAllowance . $rule->fh_rule_condition->m_name . $ruleValue;
                        $result = $expressionLanguage->evaluate($expression);
                        $ruleMatched = $result ? true : false;
                        break;
                }
            }
            return $ruleMatched;
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    public static function getApprovalOrRejectionData($requestId, $statusId, $moduleId, $approverId = null, $masterModuleId = null)
    {
        $user = Auth::user();
        if ($approverId) {
            $user = Employee::find($approverId);
        }
        $nextApprover = null;

        switch ($masterModuleId) {
            case 146:
                $model = TadaClaim::class;
                $fields = ['tc_next_approver as next_approver', 'tc_emp_id', 'tc_am_id', 'tc_trp_id', 'tc_stage_completed'];
                break;

            case 145:
                $model = TadaRequestPlan::class;
                $fields = ['trp_next_approver as next_approver', 'trp_emp_id', 'trp_am_id', 'trp_id', 'trp_stage_completed'];
                break;

            case 199:
                $model = AdvanceLog::class;
                $fields = ['adl_next_approver as next_approver', 'adl_approver_id', 'adl_am_id', 'adl_id', 'adl_stage_completed'];
                break;

            case 229:
                $model = AttendanceException::class;
                $fields = ['ae_next_approver as next_approver', 'ae_emp_id', 'ae_am_id', 'ae_id', 'ae_stage_completed'];
                break;

            case 339:
                $model = GatePass::class;
                $fields = ['gtp_next_approver as next_approver', 'gtp_emp_id', 'gtp_am_id', 'gtp_id', 'gtp_stage_completed'];
                break;

            case 250:
                $model = LeaveRequest::class;
                $fields = ['lvr_next_approver as next_approver', 'lvr_emp_id', 'lvr_am_id', 'lvr_id', 'lvr_stage_completed'];
                break;

            case 249:
                $model = AttendanceRecord::class;
                $fields = ['atd_next_approver as next_approver', 'atd_emp_id', 'atd_am_id', 'atd_id', 'atd_stage_completed'];
                break;

            case 442:
                $model = LoanRequest::class;
                $fields = ['lnr_next_approver as next_approver', 'lnr_emp_id', 'lnr_am_id', 'lnr_id', 'lnr_stage_completed'];
                break;

            default:
                $fields = null;
                break;
        }

        if (!empty($fields)) {
            [$nextApproverField, $empField, $amField, $idField, $completedField] = $fields;

            $nextApprover = $model::with('fh_employee')
                ->selectRaw("$nextApproverField, $empField")
                ->where($amField, $moduleId)
                ->where($idField, $requestId)
                ->whereNot($completedField, 1)
                ->first();
        }
        // $nextApprover = TadaClaim::with('fh_employee')->select('tc_next_approver as next_approver', 'tc_emp_id')
        //     ->where('tc_am_id', $moduleId)->where('tc_trp_id', $requestId)
        //     ->whereNot('tc_stage_completed', 1)
        //     ->union(
        //         TadaRequestPlan::with('fh_employee')->select('trp_next_approver as next_approver', 'trp_emp_id')
        //             ->where('trp_am_id', $moduleId)
        //             ->where('trp_id', $requestId)
        //             ->whereNot('trp_stage_completed', 1)
        //             ->union(
        //                 AdvanceLog::with('fh_employee')->select('adl_next_approver as next_approver', 'adl_approver_id')
        //                     ->where('adl_am_id', $moduleId)->where('adl_id', $requestId)
        //                     ->whereNot('adl_stage_completed', 1)
        //                     ->union(
        //                         AttendanceException::with('fh_employee')->select('ae_next_approver as next_approver', 'ae_emp_id')
        //                             ->where('ae_am_id', $moduleId)->where('ae_id', $requestId)
        //                             ->whereNot('ae_stage_completed', 1)->union(
        //                                 GatePass::with('fh_employee')->select('gtp_next_approver as next_approver', 'gtp_emp_id')
        //                                     ->where('gtp_am_id', $moduleId)->where('gtp_id', $requestId)
        //                                     ->whereNot('gtp_stage_completed', 1)->union(
        //                                         LeaveRequest::with('fh_employee')->select('lvr_next_approver as next_approver', 'lvr_emp_id')
        //                                             ->where('lvr_am_id', $moduleId)->where('lvr_id', $requestId)
        //                                             ->whereNot('lvr_stage_completed', 1)->union(
        //                                                 AttendanceRecord::with('fh_employee')->select('atd_next_approver as next_approver', 'atd_emp_id')
        //                                                     ->where('atd_am_id', $moduleId)->where('atd_id', $requestId)
        //                                                     ->whereNot('atd_stage_completed', 1)
        //                                                     ->union(
        //                                                         LoanRequest::with('fh_employee')->select('lnr_next_approver as next_approver', 'lnr_emp_id')
        //                                                             ->where('lnr_am_id', $moduleId)->where('lnr_id', $requestId)
        //                                                             ->whereNot('lnr_stage_completed', 1)
        //                                                     )
        //                                             )
        //                                     )
        //                             )
        //                     )
        //             )
        //     )->first();
        $emp_d_id = $nextApprover ? optional($nextApprover->fh_employee)->emp_d_id : null;
        $approvalDataQuery = ProcessApprover::whereHas('fh_approval_module', function ($query) use ($moduleId) {
            $query->where('am_id', $moduleId);
        })->where('pa_emp_id', $user->emp_id)
            ->where(function ($query) use ($emp_d_id) {
                $query->where('pa_flow', 'business')
                    ->orWhere(function ($query) use ($emp_d_id) {
                        $query->where('pa_flow', 'department')
                            ->where('pa_d_id', $emp_d_id);
                    });
            });
        $approvalData = $approvalDataQuery->first();

        if ($approvalData && $nextApprover) {
            if (($approvalData->pa_type == 'and') && ($approvalData->pa_sequence == ($nextApprover->next_approver ?? 1))) {
                $approvalData = $approvalDataQuery->whereHas('fh_approval_module', function ($query) use ($user, $requestId, $statusId) {
                    $query->whereDoesntHave('fh_approval_logs', function ($query1) use ($user, $requestId, $statusId) {
                        $query1->where('log_request_id', $requestId)
                            ->where('log_status', $statusId)
                            ->where('log_user_id', $user->emp_id)
                            ->where('log_status', 170);
                    });
                })->first();
            } elseif (($approvalData->pa_type == 'single') || ($approvalData->pa_type == 'anyone')) {

                $approvalData = $approvalDataQuery->whereHas('fh_approval_module', function ($query) use ($requestId, $statusId) {
                    $query->whereDoesntHave('fh_approval_logs', function ($query1) use ($requestId, $statusId) {
                        $query1->where('log_request_id', $requestId)
                            ->where('log_status', $statusId)
                            ->where('log_status', 170);
                    });
                })->first();
            } else {
                $approvalData = null;
            }
        } else {
            $approvalData = null;
        }
        return $approvalData;
    }

	public static function isApprovalCompleted($b_id, $module_id, $request_id, $emp_d_id, $emp_id = null)
    {
        $approvalStages = ApprovalModule::where([
            'am_b_id' => $b_id,
            'am_module_id' => $module_id
        ])->get();

        $approvalCount = 0;
        $approvalLogCount = 0;

        if (count($approvalStages)) {
            // Hierarchy-wise approval
            foreach ($approvalStages as $stage) {
                $stageApprovers = $stage->filteredProcessApprovers($emp_d_id)->get();

                foreach ($stageApprovers as $approver) {
                    $log = ApprovalLog::where([
                        'log_request_id' => $request_id,
                        'log_am_id' => $approver->pa_am_id,
                        'log_status' => $approver->pa_status_id,
                        'log_user_id' => $approver->pa_emp_id
                    ])->first();

                    if ($approver->pa_type == 'and') {
                        if ($log) {
                            $approvalLogCount++;
                        }
                        $approvalCount++;
                    } else {
                        if ($log) {
                            $approvalLogCount++;
                        }
                        $approvalCount = 1; // Only 1 needed for OR
                    }
                }
            }
        } else {
            // Employee-wise approval
            $approvalMapping = ApprovalHelper::getApprovalMapping($b_id, $emp_id, $module_id);
            $getApprovalArray = ApprovalHelper::getApprovalArray($approvalMapping);

            foreach ($getApprovalArray as $empId) {
                $log = ApprovalLog::where([
                    'log_request_id' => $request_id,
                    'log_module_id' => $module_id,
                    'log_user_id' => $empId
                ])->first();

                if ($log) {
                    $approvalLogCount++;
                }
                $approvalCount++;
            }
        }

        return $approvalCount == $approvalLogCount ? true : false;
    }



    public static function checkApproval($b_id, $module_id, $request_id, $emp_d_id, $emp_id = null)
    {
        $approvalStages = ApprovalModule::where(['am_b_id' => $b_id, 'am_module_id' => $module_id])->get();

        $approvalCount = 0;
        $approvalLogCount = 0;
        if (count($approvalStages)) {
            foreach ($approvalStages as $stage) {
                $stage = $stage->filteredProcessApprovers($emp_d_id)->get();
                foreach ($stage as $approver) {
                    if ($approver->pa_type == 'and') {
                        $log = ApprovalLog::where(['log_request_id' => $request_id, 'log_am_id' => $approver->pa_am_id, 'log_status' => $approver->pa_status_id, 'log_user_id' => $approver->pa_emp_id])->first();
                        if ($log) {
                            $approvalLogCount++;
                        }
                        $approvalCount++;
                    } else {
                        $log = ApprovalLog::where(['log_request_id' => $request_id, 'log_am_id' => $approver->pa_am_id, 'log_status' => $approver->pa_status_id, 'log_user_id' => $approver->pa_emp_id])->first();
                        if ($log) {
                            $approvalLogCount++;
                        }
                        $approvalCount = 1;
                    }
                }
            }
        } else {
            $approvalMapping =  ApprovalHelper::getApprovalMapping($b_id, $emp_id, $module_id);
            $getApprovalArray = ApprovalHelper::getApprovalArray($approvalMapping);
            foreach ($getApprovalArray as $key => $item) {
                $log = ApprovalLog::where(['log_request_id' => $request_id, 'log_module_id' => $module_id,  'log_user_id' => $item])->first();
                if ($log) {
                    $approvalLogCount++;
                }
                $approvalCount++;
            }
        }
        $trueOrfalse = $approvalCount == $approvalLogCount;

        return [
            'trueorfalse' => $trueOrfalse,
            'approvalcount' => $approvalCount,
            'approvallog_count' => $approvalLogCount
        ];
    }


    public static function getEditableStatus($b_id, $module_id, $request_id, $status_id, $is_auto_approval, $emp_d_id, $emp_id)
    {

        $editableStatus = ['is_trp_plan_editable' => false, 'is_trp_detail_editable' => false, 'is_trp_expense_editable' => false, 'is_trp_claimable' => false];

        //common for Auto and Manual Approval
        if (in_array($status_id, [139, 192])) { //139=='Pending, 192=='Recall'
            $editableStatus['is_trp_plan_editable'] = true;
            $editableStatus['is_trp_detail_editable'] = false;
            $editableStatus['is_trp_expense_editable'] = false;
            $editableStatus['is_trp_claimable'] = false;
        } else {
            if ($is_auto_approval) { //Auto Approval
                if ($status_id == 171) { //171=='Auto Approved'
                    $editableStatus['is_trp_plan_editable'] = false;
                    $editableStatus['is_trp_detail_editable'] = true;
                    $editableStatus['is_trp_expense_editable'] = true;
                    $editableStatus['is_trp_claimable'] = true;
                }
            } else { // Manual Approval
                if (in_array($status_id, [140])) { // 140 == 'Requested'
                    $editableStatus['is_trp_plan_editable'] = false;
                    $editableStatus['is_trp_detail_editable'] = false;
                    $editableStatus['is_trp_expense_editable'] = false;
                    $editableStatus['is_trp_claimable'] = false;
                } elseif (ApprovalHelper::isApprovalCompleted($b_id, $module_id, $request_id, $emp_d_id, $emp_id)) {
                    $editableStatus['is_trp_plan_editable'] = false;
                    $editableStatus['is_trp_detail_editable'] = true;
                    $editableStatus['is_trp_expense_editable'] = true;
                    $editableStatus['is_trp_claimable'] = true;
                }
            }
        }



        return $editableStatus;
    }

    public static function getNextApprovalDetails($type, $id, $bid)
    {
        $result = ['data' => null, 'message' => '', 'approver_name' => ''];

        $am_field = NULL;
        $requesterUserId = NULL;
        // Determine the appropriate request model based on type
        if ($type == 146) { // Claim
            $request = TadaClaim::with(['fh_process_approvers.fh_employee', 'fh_deduction_log'])
                ->where('tc_b_id', $bid)
                ->where('tc_id', $id)
                ->first();
            $statusField = 'tc_status';
            $stageField = 'tc_stage_completed';
            $am_field = 'tc_am_id';
            $requesterUserId = $request->tc_emp_id;
        } elseif ($type == 145) { // Travel
            $request = TadaRequestPlan::with(['fh_process_approvers.fh_employee', 'fh_policy_tada_travel_type'])
                ->where('trp_b_id', $bid)
                ->where('trp_id', $id)
                ->first();
            $statusField = 'trp_request_status';
            $stageField = 'trp_stage_completed';
            $am_field = 'trp_am_id';
            $requesterUserId = $request->trp_emp_id;
        } elseif ($type == 229) { // Mis-Punch
            $request = AttendanceException::with(['fh_process_approvers.fh_employee'])
                ->where('ae_b_id', $bid)
                ->where('ae_id', $id)
                ->first();
            $statusField = 'ae_status';
            $stageField = 'ae_stage_completed';
            $am_field = 'ae_am_id';
            $requesterUserId = $request->ae_emp_id;
        } elseif ($type == 339) { // GatePass
            $request = GatePass::with(['fh_process_approvers.fh_employee'])
                ->where('gtp_b_id', $bid)
                ->where('gtp_id', $id)
                ->first();
            $statusField = 'gtp_status';
            $stageField = 'gtp_stage_completed';
            $am_field = 'gtp_am_id';
            $requesterUserId = $request->gtp_emp_id;
        }elseif ($type == 442) { // Loan
            $request = LoanRequest::with(['fh_process_approvers.fh_employee'])
                ->where('lnr_b_id', $bid)
                ->where('lnr_id', $id)
                ->first();
            $statusField = 'lnr_status';
            $stageField = 'lnr_stage_completed';
            $am_field = 'lnr_am_id';
            $requesterUserId = $request->lnr_emp_id;
        } elseif ($type == 250) { // Leave
            $request = LeaveRequest::with(['fh_process_approvers.fh_employee'])
                ->where('lvr_b_id', $bid)
                ->where('lvr_id', $id)
                ->first();
            $statusField = 'lvr_status';
            $stageField = 'lvr_stage_completed';
            $am_field = 'lvr_am_id';
            $requesterUserId = $request->lvr_emp_id;
        } elseif ($type == 199) { // Advance
            $request = AdvanceLog::with(['fh_process_approvers.fh_employee', 'fh_tada_request_plan.fh_employee'])
                ->where('adl_id', $id)
                ->first();
            $request->fh_employee = $request->fh_tada_request_plan->fh_employee;
            $statusField = 'adl_request_status';
            $stageField = 'adl_stage_completed';
            $am_field = 'adl_am_id';
            $requesterUserId = $request?->fh_tada_request_plan?->trp_emp_id;

        } elseif ($type == 249) { // Attendance

            $request = AttendanceRecord::with(['fh_process_approvers.fh_employee', 'fh_employee'])
                ->where('atd_b_id', $bid)
                ->where('atd_id', $id)
                ->first();
            $statusField = 'atd_request_status';
            $stageField = 'atd_stage_completed';
            $am_field = 'atd_am_id';
            $requesterUserId = $request->atd_emp_id;
        } else {
            return ['message' => 'Invalid request type'];
        }
        // Check if request exists
        if (!$request) {
            return ['message' => 'No request found.'];
        }

        // Handle common checks for completion, rejection, and auto-approval (for travel)
        if ($request->$stageField == 1) {
            return ['message' => 'Completed'];
        }
        if ($request->$statusField == 170) {
            return ['message' => 'Request is rejected.'];
        }
        if (isset($request->fh_policy_tada_travel_type) && $request->fh_policy_tada_travel_type->pttt_approval_type_id == 197) {
            return ['message' => 'Auto Approved'];
        }

        // Handle deduction log specifically for claims
        if ($type == 146 && $request->fh_deduction_log) {
            $deductionLog = $request->fh_deduction_log->sortByDesc('dlog_id')->first();
            if ($deductionLog) {
                if (is_null($deductionLog->dlog_requester_action)) {
                    return ['message' => 'To Requester', 'data' => 1];
                } elseif ($deductionLog->dlog_requester_action === 0) {
                    return ['message' => 'Claim was declined.'];
                }
            }
        }

        if($request->$am_field){// for hierarchy  wise approval flow
             // Get the next approver
            $approverIds = $request->filteredProcessApprovers($request->fh_employee?->emp_d_id) ? $request->filteredProcessApprovers($request->fh_employee?->emp_d_id)->pluck('pa_emp_id') : collect();
            $logUserIds = $type == 146 ? ($request->fh_claim_approval_log ? $request->fh_claim_approval_log->pluck('log_user_id') : collect()) : ($request->fh_plan_approval_log ? $request->fh_plan_approval_log->pluck('log_user_id') : collect());
            $nextApprover = self::getNextApprover($approverIds, $logUserIds, $request);
            if ($nextApprover) {
                $result['approver_name'] = $nextApprover->emp_full_name;
                $result['data'] = 1;
            } else {
                $result['message'] = 'No next approval data available.';
            }

        }else{// for employee wise approval flow
            $approvalMapping = ApprovalHelper::getApprovalMapping($bid, $requesterUserId, $type);
            if ($approvalMapping) {
                $approvalArray = ApprovalHelper::getApprovalArray($approvalMapping);
                $approvalLog = ($type == 146) ? $request->fh_approval_log_employee_wise?->pluck('log_user_id')?->toArray() : $request->fh_approval_log2?->pluck('log_user_id')?->toArray();

                $diff = array_values(array_diff($approvalArray, $approvalLog));
                if ($diff) {
                    $result['approver_name'] = Employee::where('emp_id',$diff[0])->pluck('emp_full_name')->first() ??  '---';
                    $result['data'] = 1;
                }else {
                    $result['message'] = 'No next approval data available.';
                }
            }
        }
        return $result;
    }

    private static function getNextApprover($approverIds, $logUserIds, $request)
    {
        // Get the difference in user IDs and return the first missing approver
        $difference = $approverIds->diff($logUserIds);
        $firstDifference = $difference->first();

        if ($firstDifference) {
            return $request->fh_process_approvers->firstWhere('pa_emp_id', $firstDifference)->fh_employee ?? null;
        }
        return null;
    }

    public static function getApprovalMapping($bId, $empId, $moduleId)
    {
        return EmployeeApprovalMapping::where('eam_b_id', $bId)
            ->where('eam_emp_id', $empId)
            ->where('eam_module_id', $moduleId)
            ->first();
    }

    public static function getApprovalArray($approvalMapping)
    {
        $approvalMappingArray = [];
        if($approvalMapping?->approvalStatuses){
            foreach($approvalMapping->approvalStatuses as $approveStatus){
                $approvalMappingArray[] = $approveStatus['eas_approvel_id'];
            }
        }
        return $approvalMappingArray;
    }

    public static function canApprove($approvalMappingArray, $approvalLog, $userId)
    {
        $diff = array_values(array_diff($approvalMappingArray, $approvalLog));
        return isset($diff[0]) && $diff[0] == $userId;
    }

    public static function getApprovalData($data, $user, $prefix)
    {
        $masterApproveBtn = [];
        $canApprove = false;
        if (!$data->approvalData && $data->{$prefix . 'stage_completed'} != 1) {
            $approvalStatuses = [170];
            $moduleId = $prefix . 'module_id';
            $employeId = $prefix . 'emp_id';

            if ($data->$moduleId == 199) {
                $mapData = EmployeeApprovalMapping::where(['eam_module_id' => $data->$moduleId, 'eam_emp_id' => $data->fh_tada_request_plan->trp_emp_id])->first();
                $approvalMapping = self::getApprovalMapping($user->emp_b_id, $data->fh_tada_request_plan->trp_emp_id, $data->$moduleId);
            } else {
                $mapData = EmployeeApprovalMapping::where(['eam_module_id' => $data->$moduleId, 'eam_emp_id' => $data->$employeId])->first();
                $approvalMapping = self::getApprovalMapping($user->emp_b_id, $data->$employeId, $data->$moduleId);
            }
            if($mapData){
                $statusData = $mapData->approvalStatuses->where('eas_approvel_id',$user->emp_id)->pluck('eas_approvel_status')->toArray();
                $approvalStatuses = array_merge($approvalStatuses, $statusData);
                $masterApproveBtn = MasterTable::whereIn('m_id', $approvalStatuses)->orderBy('m_id', 'desc')->get();
            }
            if ($approvalMapping) {
                $logMethod = ($data->$moduleId == 146) ? 'fh_approval_log_employee_wise' : 'fh_approval_log2';
                $logData = $data?->$logMethod('orderBy', 'desc')->first();
                $requesterActPending = $logData?->fh_deductionLog?->orderBy('dlog_id', 'desc')->first();

                if ($requesterActPending && $requesterActPending->dlog_requester_action == 0) {
                    $canApprove = $requesterActPending->dlog_user_id == $user->emp_id;
                } else {
                    $approvalMappingArray = self::getApprovalArray($approvalMapping);
                    $approvalLog = $data?->$logMethod?->pluck('log_user_id')?->toArray() ?? [];
                    $canApprove = self::canApprove($approvalMappingArray, $approvalLog, $user->emp_id);
                }
            }
        }

        return compact('masterApproveBtn', 'canApprove');
    }

    public static function processApproval($request, $data, $user, $prefix)
    {
        // Start the transaction
        DB::beginTransaction();
        try {
            if ($data->{$prefix . 'module_id'} == 199) { // advance
                $approvalMapping = self::getApprovalMapping($user->emp_b_id, $data->fh_tada_request_plan->trp_emp_id, $data->{$prefix . 'module_id'});
            } elseif ($data->{$prefix . 'module_id'} == 146) { // 146==Claim

                //start check the deduction amount must be less than payable amount
                $deductionInfo = $request->deduction_info ?? [];
                if ($data && $data->fh_deduction_log->where('dlog_requester_action', 1)->isNotEmpty()) {
                    // Iterate through deduction logs where requester action is 1
                    foreach ($data->fh_deduction_log->where('dlog_requester_action', 1) as $deduction_log) {
                        $additionalInfo = json_decode($deduction_log->dlog_additional_info, true);

                        // Merge additional info into deduction info
                        foreach ($additionalInfo as $logKey => $log) {
                            $deductionInfo[$logKey] = isset($deductionInfo[$logKey])
                                ? $deductionInfo[$logKey] + $log
                                : $log; // Initialize if not set
                        }
                    }
                }
                // Validate deduction info against payable amount
                if (!empty($deductionInfo) && isset($request->payable_amount)) {
                    foreach ($deductionInfo as $key => $deductionAmount) {
                        // Ensure payable amount exists for the key
                        if (isset($request->payable_amount[$key])) {
                            if ($request->payable_amount[$key] < $deductionAmount) {

                                return ['status' => 'error', 'message' => 'Deduction amount cannot be greater than the payable amount', 'data' => ''];
                            }
                        }
                    }
                }
                //end check the deduction amount must be less than payable amount

                $approvalMapping = self::getApprovalMapping($user->emp_b_id, $data->{$prefix . 'emp_id'}, $data->{$prefix . 'module_id'});
            } else {
                $approvalMapping = self::getApprovalMapping($user->emp_b_id, $data->{$prefix . 'emp_id'}, $data->{$prefix . 'module_id'});
            }
            $approvalArray = $approvalMapping ? self::getApprovalArray($approvalMapping) : null;
            $lastApprover = $approvalArray ? end($approvalArray) : null;

            $stageComplete = ($request->log_status == 170 || $lastApprover == $user->emp_id) ? 1 : 0;
            if (($data->{$prefix . 'module_id'} == 145) || ($data->{$prefix . 'module_id'} == 249) || ($data->{$prefix . 'module_id'} == 199)) {
                $data->update([
                    $prefix . 'request_status' => $request->log_status,
                    $prefix . 'stage_completed' => $stageComplete,
                ]);
            } else {
                $data->update([
                    $prefix . 'status' => $request->log_status,
                    $prefix . 'stage_completed' => $stageComplete,
                ]);
            }
            if ($data->{$prefix . 'module_id'} == 199 && $stageComplete) { // advance
                $plan = TadaRequestPlan::where('trp_id', $request->adl_trp_id)->first();
                if ($plan && $request->log_status != 170) {
                    $plan->update(['trp_advance_allowance' => $plan->trp_advance_allowance
                        ? ($plan->trp_advance_allowance + $request->reimburse_amount)
                        : $request->reimburse_amount]);
                }

                $data->update([
                    $prefix . 'reimburse_amount' => $request->reimburse_amount
                ]);
            }

            $approval = ApprovalLog::create([
                'log_request_id' => $data->{$prefix . 'module_id'} == 146 ? $data->{$prefix . 'trp_id'}  : $data->{$prefix . 'id'},
                'log_user_id' => $user->emp_id,
                'log_user_role_id' => $user->emp_role_id,
                'log_status' => $request->log_status,
                'log_description' => $request->log_description,
                'log_module_id' => $data->{$prefix . 'module_id'},
                'log_other' => $data->{$prefix . 'module_id'} == 199 ? $request->reimburse_amount : null,
            ]);
            //start handle deduction
            if ($data->{$prefix . 'module_id'} == 146 && (isset($request->deduction_amount) && $request->deduction_amount)) { //146==Claim
                $updateData['tc_deduction_amount'] = $data->tc_deduction_amount ? ($data->tc_deduction_amount + $request->deduction_amount) : $request->deduction_amount;
                $updateData['tc_deduction_status'] = null;
                $updateData['tc_deduction_remarks'] = $request->log_description;
                DeductionLog::create([
                    'dlog_log_id' => $approval->log_id,
                    'dlog_am_id' => $data->tc_am_id,
                    'dlog_tc_id' => $data->tc_id,
                    'dlog_user_id' => $user->emp_id,
                    'dlog_user_role_id' => $user->emp_role_id,
                    'dlog_deduction_amount' => $request->deduction_amount,
                    'dlog_remarks' => $request->log_description,
                    'dlog_additional_info' => isset($request->deduction_info) ? (is_array($request->deduction_info) ? json_encode($request->deduction_info) : $request->deduction_info) : '',
                ]);

                $data->update($updateData);
            }
            //start handle deduction
            $masterTable = MasterTable::where('m_id', $request->log_status)->first();
            // Commit the transaction
            DB::commit();
            return ['status' => 'success', 'message' => optional($data->fh_module)->m_name . ' Request ' . optional($masterTable)->m_name . ' Successfully', 'data' => $approval];
        } catch (Exception $e) {
            // Rollback the transaction if an error occurs
            DB::rollBack();
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }

    public static function getDistanceAndDuration($origin, $destination)
    {
        // $apiKey = env('GOOGLE_MAPS_API_KEY');
        $apiKey = 'AIzaSyBept2iO1bVOoeXiM5_oy5H9Zv0FtDWo-Y';

        $response = Http::get("https://maps.googleapis.com/maps/api/distancematrix/json", [
            'origins' => $origin,
            'destinations' => $destination,
            'mode' => 'driving',
            'key' => $apiKey,
        ]);

        $data = $response->json();

        if ($data['status'] === 'OK' && $data['rows'][0]['elements'][0]['status'] === 'OK') {
            return [
                'distance_text' => $data['rows'][0]['elements'][0]['distance']['text'],
                'distance_value' => $data['rows'][0]['elements'][0]['distance']['value'], // meters
                'duration_text' => $data['rows'][0]['elements'][0]['duration']['text'],
                'duration_value' => $data['rows'][0]['elements'][0]['duration']['value'], // seconds
            ];
        }

        return null;
    }
}
