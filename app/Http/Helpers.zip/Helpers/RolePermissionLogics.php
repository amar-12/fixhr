<?php

namespace App\Helpers;

use App\Models\BusinessModuleAccess;
use App\Models\Menu;
use App\Models\Role;
use App\Models\RolesHasPermission;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use ChandraHemant\HtkcUtils\CommonUtils;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;

class RolePermissionLogics
{
    public static function get_menu_panel_list($id = 0, Model $eloquentModel = new Menu()){
        $dynamicConditions = [
            [
                'method' => 'where',
                'args' => ['menu_p_id',$id]
            ],
            [
                'method' => 'where',
                'args' => ['menu_status',1]
            ],
            [
                'method' => 'where',
                'args' => ['menu_sub_status',null]
            ],
            [
                'method' => 'orderBy',
                'args' => ['menu_sequence', 'ASC']
            ],
        ];
        return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);
    }

    // public static function get_menu_list(Model $eloquentModel = new Menu(), $id = '', $status = 0){
    //     $dynamicConditions = [
    //         [
    //             'method' => 'where',
    //             'args' => ['menu_status', 1]
    //         ],
    //         [
    //             'method' => 'where',
    //             'args' => ['menu_sub_status', $status]
    //         ],
    //         [
    //             'method' => 'orderBy',
    //             'args' => ['menu_sequence', 'ASC']
    //         ],
    //     ];

    //     if($id!=''){
    //         $dynamicConditions[] = ['method' => 'where', 'args' => ['menu_p_id', $id]];
    //     }
    //     return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);
    // }

    public static function get_menu_list(Model $eloquentModel = new Menu(), $id = '', $status = 0)
    {
        // Generate a unique cache key based on function parameters
        $cacheKey = 'menu_list_' . get_class($eloquentModel) . '_' . $id . '_' . $status;

        //return Cache::remember($cacheKey, 3600, function () use ($eloquentModel, $id, $status) {
            $dynamicConditions = [
                ['method' => 'where', 'args' => ['menu_status', 1]],
                ['method' => 'where', 'args' => ['menu_sub_status', $status]],
                ['method' => 'orderBy', 'args' => ['menu_sequence', 'ASC']],
            ];

            if ($id != '') {
                $dynamicConditions[] = ['method' => 'where', 'args' => ['menu_p_id', $id]];
            }

            return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);
        //});
    }

    public static function get_all_menus(Model $eloquentModel = new Menu())
    {
        $cacheKey = 'all_menus_' . get_class($eloquentModel);

        //return Cache::remember($cacheKey, 3600, function () use ($eloquentModel) {
            $dynamicConditions = [
                ['method' => 'where', 'args' => ['menu_status', 1]],
                ['method' => 'orderBy', 'args' => ['menu_sequence', 'ASC']],
            ];
            return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);
        //});
        // $dynamicConditions = [
        //     [
        //         'method' => 'where',
        //         'args' => ['menu_status', 1]
        //     ],
        //     [
        //         'method' => 'orderBy',
        //         'args' => ['menu_sequence', 'ASC']
        //     ],
        // ];
        // return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);

        // $user = Auth::user();
        // $moduleIds = BusinessModuleAccess::where('bma_b_id',$user->emp_b_id)->pluck('bma_mdl_id')->toArray();
        // $menus = Menu::where('menu_status', 1)
        // ->whereHas('fh_modules', function ($query) use ($moduleIds) {
        //     $query->whereIn('mdl_id', $moduleIds);
        // })
        // ->orderBy('menu_sequence', 'ASC')
        // ->get();
        // return $menus;    // return
    }

    /*----------------------------------------------------------------------------------------------------------*/

    // For Role Permissions
    public static function get_role_list(Model $eloquentModel = new Role()){
        $user = Auth::user();
        $dynamicConditions = [
            [
                'method' => 'where',
                'args' => ['role_b_id', null]
            ],
            [
                'method' => 'orWhere',
                'args' => ['role_b_id', $user->emp_b_id]
            ],
        ];
        return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions);
    }

    public static function get_role_wise_menu_permissions($roleId = null, Model $eloquentModel = new RolesHasPermission()){
        $user = Auth::user();
        $roleId = $roleId ?? $user->emp_role_id;
        // Generate a unique cache key
        $cacheKey = 'role_permissions_' . get_class($eloquentModel) . '_' . $roleId . '_' . $user->emp_b_id;
        //return Cache::remember($cacheKey, 600, function () use ($eloquentModel, $roleId, $user) {
            $dynamicConditions = [
                ['method' => 'where', 'args' => ['rhp_role_id', $roleId]],
                ['method' => 'where', 'args' => ['rhp_b_id', $user->emp_b_id]],
            ];

            return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions, true);
        //});
        // $dynamicConditions = [
        //     [
        //         'method' => 'where',
        //         'args' => ['rhp_role_id', $roleId]
        //     ],
        //     [
        //         'method' => 'where',
        //         'args' => ['rhp_b_id', $user->emp_b_id]
        //     ],
        // ];
        // return CommonUtils::getCustomModelData($eloquentModel, $dynamicConditions, true);
    }

    public static function get_admin_role_permission($roleId){
        $value = [];
        $permission = self::get_role_wise_menu_permissions($roleId);
        if ($permission && isset($permission->rhp_permissions) && $permission->rhp_permissions !== 'null') {
            foreach (json_decode($permission->rhp_permissions) as $data => $v) {
                $value[] = [$data, $v];
            }
        }
        return $value;
    }

    /*----------------------------------------------------------------------------------------------------------*/

    // For check route permission to enable / disable / hide / show buttons
    public static function check_route_permission($route, $methodType, $menus = '', $rolePermissions = '')
    {
        $user = Auth::user();
        if($menus == ''){
            $menus = self::get_all_menus()->toArray();
        }
        if($rolePermissions == ''){
            $rolePermissions = self::get_admin_role_permission($user->emp_role_id);
        }
        // Find the parent menu ID based on the route and methodType
        $parentMenuId = self::find_parent_menu_id($menus, $route, $methodType);

        if ($parentMenuId === null) {
            return false;
        }

        // Check permissions starting from the found parent menu ID
        return self::check_permissions_for_route($menus, $parentMenuId, $rolePermissions, $methodType);
    }

    public static function check_permissions_for_route($menus, $menuId, $rolePermissions, $methodType)
    {
        while ($menuId != 0) {
            foreach ($rolePermissions as $p_menu) {
                if ($p_menu[0] == $menuId) {
                    return self::match_permission_for_route($p_menu[1], $methodType);
                }
            }

            // Fetch the parent menu ID
            $menuDetails = self::get_menu_detail($menus, $menuId);
            if (empty($menuDetails) || !isset($menuDetails[0]['menu_p_id'])) {
                break;
            }

            $menuId = $menuDetails[0]['menu_p_id'];
        }

        return false;
    }

    public static function match_permission_for_route($permissions, $methodType)
    {
        switch ($methodType) {
            case 115:
                return isset($permissions->create) && $permissions->create === 'on';
            case 116:
                return isset($permissions->read) && $permissions->read === 'on';
            case 117:
                return isset($permissions->update) && $permissions->update === 'on';
            case 118:
                return isset($permissions->delete) && $permissions->delete === 'on';
            default:
                return false;
        }
    }

    public static function find_parent_menu_id($menus, $route, $methodType)
    {
        $filteredMenus = array_filter($menus, function($menu) use ($route, $methodType) {
            return $menu['menu_route'] == $route && $menu['menu_route_type_id'] == $methodType;
        });

        if (empty($filteredMenus)) {
            return null;
        }

        return array_values($filteredMenus)[0]['menu_p_id'];
    }


    /*----------------------------------------------------------------------------------------------------------*/

    // For sidebar active and expanded
    public static function is_active_sidebar_menu($menus, $parentMenuId)
    {
        $currentUri = Route::current()->uri();
        return self::check_uri_match($menus, $parentMenuId, $currentUri, []);
    }

    public static function check_uri_match($menus, $menuId, $currentUri, $visitedMenus)
    {
        // Prevent revisiting the same menu to avoid infinite loops
        if (in_array($menuId, $visitedMenus)) {
            return false;
        }

        // Mark the current menu as visited
        $visitedMenus[] = $menuId;

        // Fetch the menu details from the array
        $menuDetails = array_filter($menus, function($menu) use ($menuId) {
            return $menu['menu_id'] == $menuId;
        });

        foreach ($menuDetails as $menu) {
            if (isset($menu['menu_route']) && (trim($menu['menu_route']) === $currentUri || trim($menu['menu_route']) === str_replace(['/{id}', '/{id?}'], '', $currentUri))) {
                return true;
            }

            // Recursively check sub-menus
            $subMenuDetails = array_filter($menus, function($submenu) use ($menu) {
                return $submenu['menu_p_id'] == $menu['menu_id'];
            });

            if (!empty($subMenuDetails)) {
                foreach ($subMenuDetails as $subMenu) {
                    if (self::check_uri_match($menus, $subMenu['menu_id'], $currentUri, $visitedMenus)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public static function get_menu_detail($menus, $condition)
    {
        if (is_array($condition)) {
            return array_filter($menus, function($menu) use ($condition) {
                foreach ($condition as $key => $value) {
                    if ($menu[$key] != $value) {
                        return false;
                    }
                }
                return true;
            });
        } else {
            return array_filter($menus, function($menu) use ($condition) {
                return $menu['menu_id'] == $condition;
            });
        }
    }

    public static function clearSpecificCache() {
        // $user = Auth::user();

        // // Clear the three specific cache entries
        // Cache::forget('all_menus_App\Models\Menu');
        // Cache::forget('role_permissions_App\Models\RolesHasPermission_' . $user->emp_role_id . '_' . $user->emp_b_id);

        // // Optionally, return a success response or log the cache clearing
        // return response()->json(['message' => 'Caches cleared successfully!']);
        Artisan::call('optimize:clear');
        Artisan::call('cache:clear');
        Artisan::call('view:clear');
        Artisan::call('config:cache');
        Artisan::call('route:clear');
    }


}

