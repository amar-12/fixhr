<?php

namespace App\Helpers\Aws;

use App\Helpers\CentralLogics;
use App\Models\ApiCredential;
use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
use Illuminate\Support\Facades\Cache;


class AwsHelper
{
    protected $s3;

    public function __construct()
    {
        // if(env('STORE_ON_S3')){
            $cache_key = hash('sha256', 'aws_creds');
            $record = Cache::remember($cache_key, now()->addHours(24), function () {
                return ApiCredential::where(['apc_type'=>'aws','apc_is_active'=>1])->first();
            });

            try {
                if($record){
                    $key = CentralLogics::encrypt_or_decrypt($record->apc_key,'decrypt');
                    $secret = CentralLogics::encrypt_or_decrypt($record->apc_secret,'decrypt');
                    $this->s3 = new S3Client([
                        'version'     => $record->apc_version,
                        'region'      => $record->apc_region,
                        'credentials' => [
                            'key'    => $key,
                            'secret' => $secret,
                        ]
                    ]);
                }
            } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
                \Log::error("Decryption failed for AWS credentials: " . $e->getMessage());
            }
       //}
    }

    public function uploadFileToS3(string $bucket, string $imagePath, $file)
    {
        try {
            $ext = $file->getClientOriginalExtension();
            $result = $this->s3->putObject([
                'Bucket' => $bucket,
                'Key'    => $imagePath,
                'ContentType'        => $ext,
                'ContentDisposition' => 'inline',
                'Body'   => fopen($file, 'r'),
            ]);
            return ['status' => true, 'ObjectURL' => $result['ObjectURL'] ?? null];
        } catch (S3Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    public function getObjectFromS3(string $bucket, string $objectKey)
    {
        try {
            $result = $this->s3->getObject([
                'Bucket' => $bucket,
                'Key'    => $objectKey,
            ]);
            return $result['Body']->getContents();
        } catch (S3Exception $e) {
            return null;
        }
    }

    public function deleteFileFromS3(string $bucket, string $objectKey)
    {
        try {
            $this->s3->deleteObject([
                'Bucket' => $bucket,
                'Key'    => $objectKey,
            ]);

            return ['status' => true, 'message' => 'File deleted successfully'];
        } catch (S3Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }
}
