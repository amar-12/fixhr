<?php

namespace App\Helpers;

use App\Models\Employee;
use App\Models\MasterTable;
use App\Models\PolicyLeave;
use App\Models\LeaveRequest;
use App\Models\MailTemplate;
use Illuminate\Http\Request;
use App\Models\AttendanceLog;
use Illuminate\Support\Carbon;
use App\Models\PolicyLeaveType;
use App\Models\AttendanceRecord;
use App\Models\PolicyHolidayList;
use App\Models\AttendanceException;
use Illuminate\Support\Facades\Log;
use App\Models\PolicyTadaTravelType;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Session;
use ChandraHemant\HtkcUtils\CommonUtils;
use Illuminate\Support\Facades\Request as FacadesRequest;
use Illuminate\Support\Facades\Crypt;


class CentralLogics
{
    /**
     * Laeravel Custom Helpers
     *
     * @package     Laravel Helpers
     * @subpackage  Custom Helpers
     * @category    Helpers
     * @author      Hemant Chandra
     */

    public static function timezone_configure()
    {
        return Carbon::now()->timezone('Asia/Kolkata')->toDateTimeString();
    }


    public static function send_sms($phone, $message)
    {
        // Your SMS API integration here
    }


    public static function getAttendanceRecord($employeeId, $date)
    {
        // Initialize default values
        $user =   Auth::user();
        $status = 0;
        $leaveName = null;
        $holidayName = null;

        $leaveRequest = LeaveRequest::where('lvr_emp_id', $employeeId)->whereDate('lvr_start_date', '<=', $date)->whereDate('lvr_end_date', '>=', $date)->where('lvr_status', 'APPROVED')->first();

        if ($leaveRequest) {
            switch (true) {
                case ($leaveRequest->lvr_status === 'approved' && $leaveRequest->lvr_leave_day_type_id == 201):
                    $leaveName = PolicyLeave::where('m_id',  $user->emp_b_id)->where('pl_id', $leaveRequest->lvr_pl_id)->pluck('pl_name');
                    $status = 201; // Full-day leave
                    break;

                case ($leaveRequest->lvr_status === 'approved' && $leaveRequest->lvr_leave_day_type_id == 202):
                    $leaveName = PolicyLeave::where('m_id',  $user->emp_b_id)->where('pl_id', $leaveRequest->lvr_pl_id)->pluck('pl_name');
                    $status = 202; // Half-day leave
                    break;

                case ($leaveRequest->lvr_status === 'pending' && $leaveRequest->lvr_leave_day_type_id == 202 || $leaveRequest->lvr_leave_day_type_id == 201):
                    $status = 203; // Leave not approved (absent)
                    break;
            }
        }

        $attendanceException = AttendanceException::whereHas('fh_attendance_policy', function ($query) {
            $query->whereColumn('ap_id', 'ae_ap_id');
        })
            ->where('ae_emp_id', $employeeId)
            ->whereDate('ae_date', $date)
            ->first();

        if ($attendanceException) {
            if ($attendanceException->ae_status === 'approved') {
                $status = 251; // Mispunch approved (present)
            } elseif (is_null($attendanceException->ae_status)) {
                $status = 228; // Mispunch not approved
            }
        }

        $holiday = PolicyHolidayList::whereHas('fh_attendance_policy', function ($query) {
            $query->whereColumn('ap_id', 'phl_ap_id');
        })
            ->where('phl_b_id', $user->emp_b_id)
            ->where('phl_start_date', '<=', $date)
            ->where('phl_end_date', '>=', $date)
            ->first();

        if ($holiday) {
            if ($holiday->phl_type_id == 205) {
                $status = 205; // Public holiday
            } elseif ($holiday->phl_type_id == 206) {
                $status = 206; // Company-specific holiday
            }
            $holidayName = $holiday->phl_name;
        }

        return [
            'status' => $status,
            'leave_name' => $leaveName,
            'holiday_name' => $holidayName,
        ];
    }

    public static function dynamicDelete($modelClass, $id)
    {
        try {
            // Ensure the model class exists
            if (!class_exists($modelClass)) {
                return ['error' => 'Invalid model specified.'];
            }

            $record = $modelClass::find($id);

            if (!$record) {
                return ['error' => 'Record not found.'];
            }

            $record->delete();
            if (class_basename($modelClass) == 'PolicyShiftTiming') {
                $modelClass = 'Policy Shift';
                return ['success' => $modelClass . ' deleted successfully.'];
            }
            return ['success' => class_basename($modelClass) . ' deleted successfully.'];
        } catch (QueryException $e) {
            if ($e->getCode() == 23000) { // Integrity constraint violation
                // Extract the referenced table name from the error message
                $errorMessage = $e->getMessage();
                preg_match("/`(\w+?)`\.\`(\w+?)`/", $errorMessage, $matches);
                $referencedTable = $matches[2] ?? 'an unknown table';
                if ($referencedTable == 'fh_employees') {
                    $referencedTable  = 'Employee';
                }
                // return ['error' => "Can't delete this record because it is referenced by the '{$referencedTable}' table."];
                return ['error' => "Unable to delete. This record is linked to the '{$referencedTable}' records and must be removed first"];
            }

            // Log unexpected errors for debugging
            Log::error('Delete Error: ' . $e->getMessage());
            return ['error' => 'An unexpected error occurred.'];
        }
    }


    public static function getMonthlyAttendanceSummary($employee, $monthFilter, $weekOfDates)
    {
        $user = Auth::user();
        [$year, $month] = explode('-', $monthFilter);

        $presentCount = 0;
        $leaveCount = 0;
        $approvedLeaveCount = 0;
        $holidayCount = 0;

        $absentCount = 0;
        $halfDayCount = 0;
        $missedPunchCount = 0;
        $approvedMissedPunchCount = 0;
        $overtimeCount = 0;
        $lateCount = 0;
        $earlyExitCount = 0;

        $startDate = Carbon::createFromDate($year, $month, 1);
        $endDate = $startDate->copy()->endOfMonth();


        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();
        $dateRange = $startDate->toPeriod($endDate);

        $holiday_record_exits = PolicyHolidayList::where('phl_b_id', $user->emp_b_id)->where(function ($q) use ($startDate, $endDate) {
            $q->whereBetween('phl_start_date', [$startDate, $endDate])
              ->orWhereBetween('phl_end_date', [$startDate, $endDate]);
        })->get();
        $holidaysByDate = collect();
        foreach ($holiday_record_exits as $holiday) {
            $start = Carbon::parse($holiday->phl_start_date);
            $end = Carbon::parse($holiday->phl_end_date);

            while ($start->lte($end)) {
                $holidaysByDate->put($start->toDateString(), $holiday);
                $start->addDay();
            }
        }


            $monthDetails =  ['date' => $startDate->format('Y-m-d'), 'user_friendly_date' => $startDate->format('d-M-Y'), 'day' => $startDate->format('l')];

            $attendanceData = self::newGetMonthlyAttendanceDetails($employee, $month, $year, $holidaysByDate, $weekOfDates);

            // $presentCount = $presentCount + $attendanceData['presentCount'];
            // $leaveCount = $leaveCount + $attendanceData['leaveCount'];

            // $absentCount = $absentCount + $attendanceData['absentCount'];
            // $halfDayCount = $halfDayCount + $attendanceData['halfDayCount'];
            // $missedPunchCount = $missedPunchCount + $attendanceData['missedPunchCount'];
            // $overtimeCount = $overtimeCount + $attendanceData['overtimeCount'];
            // $lateCount = $lateCount + $attendanceData['lateCount'];
            // $earlyExitCount = $earlyExitCount + $attendanceData['earlyExitCount'];
            // $holidayCount = $holidayCount + $attendanceData['holidayCount'];
            // $approvedLeaveCount = $approvedLeaveCount + $attendanceData['approvedLeaveCount'];
            // $approvedMissedPunchCount = $approvedMissedPunchCount + $attendanceData['approvedMissedPunchCount'];



            $presentCount = collect($attendanceData)->sum('presentCount');
            $leaveCount = collect($attendanceData)->sum('leaveCount');
            $holidayCount = collect($attendanceData)->sum('holidayCount');
            $weekOffCount = collect($attendanceData)->sum('weekOffCount');
            $absentCount = collect($attendanceData)->sum('absentCount');
            $halfDayCount = collect($attendanceData)->sum('halfDayCount');
            $missedPunchCount = collect($attendanceData)->sum('missedPunchCount');
            $overtimeCount = collect($attendanceData)->sum('overtimeCount');
            $lateCount = collect($attendanceData)->sum('lateCount');
            $earlyExitCount = collect($attendanceData)->sum('earlyExitCount');
            $approvedLeaveCount = collect($attendanceData)->sum('approvedLeaveCount');
            $approvedMissedPunchCount = collect($attendanceData)->sum('approvedMissedPunchCount');






        return [
            'presentCount' => $presentCount,
            'leaveCount' => $leaveCount,
            'holidayCount' => $holidayCount,
            'weekOffCount' => count($weekOfDates),
            'absentCount' => $absentCount,
            'halfDayCount' => $halfDayCount,
            'missedPunchCount' => $missedPunchCount,
            'overtimeCount' => $overtimeCount,
            'lateCount' => $lateCount,
            'earlyExitCount' => $earlyExitCount,
            'approvedLeaveCount' => $approvedLeaveCount,
            'approvedMissedPunchCount' => $approvedMissedPunchCount,
        ];
    }


    public static function getMonthlyAttendanceDetails($employee, $date, $weekOfDates)
    {

        $absentStatus = MasterTable::where('m_id', 203)->first();

        $rowData = [
            'status' => '-',
            'status_id' => '-',
            'status_code' => '-',
            'statusColor' => '#BDBDBD',
            'checkInTime' => null,
            'checkOutTime' => null,
            'updatedBy' => null,
            'workingHour' => null,
            'OT' => null,
            'earlyExit' => null,
            'late' => null,
            'attendance_remark' => '--',
            'checkInLocation' => '--',
            'checkOutLocation' => '--',
            'checkInPhoto' => [],
            'checkOutPhoto' => [],
            'atd_segments' => [],
            'presentCount' => 0,
            'leaveCount' => 0,
            'holidayCount' => 0,
            'weekOffCount' => 0,
            'absentCount' => 0,
            'halfDayCount' => 0,
            'missedPunchCount' => 0,
            'overtimeCount' => 0,
            'lateCount' => 0,
            'earlyExitCount' => 0,
            'approvedLeaveCount' => 0,
            'approvedMissedPunchCount' => 0,
            'isApproved' => null,
            'previousCheckInTime' => null,
            'previousCheckOutTime' => null,
            'previousLate' => null,
            'previousExit' => null,
            'UPL' => 0,
        ];

        if ($employee->emp_date_of_joining <= Carbon::parse($date)->format('Y-m-d')) {

            $is_found = null;
            $attendance_record_exit = $employee->attendance_record()->whereDate('atd_date', $date)->first();
            $attendance_log = AttendanceLog::where('al_emp_id', $employee->emp_id)->whereDate('al_date', $date)->orderBy('al_id', 'desc')->first();

            if ($attendance_record_exit && $attendance_record_exit->fh_attendance_status) {

                if ($attendance_record_exit->atd_attendance_status == 252) { //Half Day
                    $rowData['halfDayCount'] = 1;
                    $rowData['presentCount']  = 0.5;
                    $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
                    $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
                    $is_found = 1;
                } else {
                    $missedPunch =  AttendanceException::where('ae_b_id', $employee->emp_b_id)->where('ae_emp_id', $employee->emp_id)->where('ae_date', '=', $date)->first();
                    if (!$missedPunch) {
                        $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
                        $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
                        if ($attendance_record_exit->atd_attendance_status == 251) {
                            $rowData['presentCount'] = 1; //Present
                        }
                    }
                    $is_found = 1;
                }

                if ($attendance_record_exit->atd_is_overtime == 1) {
                    $rowData['overtimeCount'] = 1;
                }

                if ($attendance_record_exit->atd_is_late == 1) {
                    $rowData['lateCount'] = 1;
                }

                if ($attendance_record_exit->atd_is_early_exit == 1) {
                    $rowData['earlyExitCount'] = 1;
                }

                $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name;
                $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
                $rowData['checkInTime'] = $attendance_record_exit->atd_check_in_time ? Carbon::parse($attendance_record_exit->atd_check_in_time)->format('h:i A') : '-';
                $rowData['checkOutTime'] = $attendance_record_exit->atd_check_out_time ? Carbon::parse($attendance_record_exit->atd_check_out_time)->format('h:i A') :  '-';
                $rowData['workingHour'] = $attendance_record_exit->atd_total_worked_hours ? number_format($attendance_record_exit->atd_total_worked_hours, 2) : '-';
                $rowData['earlyExit'] = ($attendance_record_exit->atd_is_early_exit && $attendance_record_exit->atd_early_exit_duration) ? number_format($attendance_record_exit->atd_early_exit_duration, 2) :  null;
                $rowData['late'] = ($attendance_record_exit->atd_is_late && $attendance_record_exit->atd_late_duration) ? number_format($attendance_record_exit->atd_late_duration, 2) :  null;
                $rowData['OT'] = ($attendance_record_exit->atd_is_overtime && $attendance_record_exit->atd_overtime_hours) ? number_format($attendance_record_exit->atd_overtime_hours, 2) :  null;
                $rowData['attendance_remark'] = $attendance_record_exit->atd_remark  ? $attendance_record_exit->atd_remark :  '-';
                $rowData['checkInLocation'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_location ? $attendance_record_exit->atd_punchin_location : '--';
                $rowData['checkOutLocation'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_location ? $attendance_record_exit->atd_punchout_location : '--';
                $rowData['checkInPhoto'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_photo ? json_decode($attendance_record_exit->atd_punchin_photo) : [];
                $rowData['checkOutPhoto'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_photo ? json_decode($attendance_record_exit->atd_punchout_photo) : [];
                $rowData['atd_segments'] =  $attendance_record_exit && $attendance_record_exit->atd_segments ? [json_decode($attendance_record_exit->atd_segments)] : [];
                $rowData['updatedBy'] = $attendance_record_exit->updated_by  ? $attendance_record_exit->updated_by->emp_full_name :  '-';
                if ($attendance_log) {
                    $rowData['previousCheckInTime'] = $attendance_log->al_check_in_time ? Carbon::parse($attendance_log->al_check_in_time)->format('h:i A') : '-';
                    $rowData['previousCheckOutTime'] = $attendance_log->al_check_out_time ? Carbon::parse($attendance_log->al_check_out_time)->format('h:i A') :  '-';
                    $rowData['previousLate'] = ($attendance_log->al_is_late && $attendance_log->al_late_duration) ? number_format($attendance_log->al_late_duration, 2) : null;
                    $rowData['previousExit'] = ($attendance_log->al_is_early_exit && $attendance_log->al_early_exit_duration) ? number_format($attendance_log->al_early_exit_duration, 2) : null;
                }
            }


            $half_day_present = ($attendance_record_exit && $attendance_record_exit->atd_attendance_status == 252); //252==Half Day
            if (is_null($is_found) || $half_day_present) {

                $leave_record_exit = $employee->leave_requests()->where('lvr_start_date', '<=', Carbon::parse($date)->format('Y-m-d'))->where('lvr_end_date', '>=', Carbon::parse($date)->format('Y-m-d'))->first();

                if ($leave_record_exit && $leave_record_exit->fh_leave_cat_type) {
                    if ($leave_record_exit->fh_leave_day_type->m_id == 201) {
                        $rowData['leaveCount'] = 1;
                        if ($leave_record_exit->lvr_status != 170 && $leave_record_exit->lvr_stage_completed) {
                            $rowData['approvedLeaveCount'] = 1;
                        }
                    } else {
                        $rowData['leaveCount'] = 0.5;
                        if ($leave_record_exit->lvr_status != 170 && $leave_record_exit->lvr_stage_completed) {
                            $rowData['approvedLeaveCount'] = 0.5;
                        }
                    }

                    $rowData['isApproved'] = ($leave_record_exit->lvr_status != 170 && $leave_record_exit->lvr_stage_completed);
                    $leave_category_ids = MasterTable::where('m_group', 'LEAVE_CATEGORY')->pluck('m_id')->toArray();
                    if (in_array($leave_record_exit->fh_leave_cat_type->m_id, $leave_category_ids) && $rowData['isApproved']) {
                        $is_found = 1;
                        if ($half_day_present) { // For half-day leave and half-day present
                            if ($leave_record_exit->fh_leave_day_segment->m_id == 236) {
                                $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id . '/' . $leave_record_exit->fh_leave_cat_type->m_id;
                                $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name . '/' . $leave_record_exit->fh_leave_cat_type->m_name;
                                $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type . '/' . $leave_record_exit->fh_leave_cat_type->m_type;
                                $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'] . '/' . json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'];
                            } elseif ($leave_record_exit->fh_leave_day_segment->m_id == 235) {
                                $rowData['status_id'] = $leave_record_exit->fh_leave_cat_type->m_id . '/' . $attendance_record_exit->fh_attendance_status->m_id;
                                $rowData['status'] = $leave_record_exit->fh_leave_cat_type->m_name . '/' . $attendance_record_exit->fh_attendance_status->m_name;
                                $rowData['status_code'] =  $leave_record_exit->fh_leave_cat_type->m_type . '/' . $attendance_record_exit->fh_attendance_status->m_type;
                                $rowData['statusColor'] = json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
                            }
                            $rowData['presentCount']  = $rowData['presentCount'] + 0.5; //if half day leave & approved count as half present
                        } elseif ($leave_record_exit->lvr_total_leave_days == 0.5) { //This case addresses situations where the leave balance is 0.5, but the leave applied exceeds 0.5.
                            if (Carbon::parse($date)->format('Y-m-d') < now()->format('Y-m-d')) {
                                $upLeave = MasterTable::where('m_id', 215)->first(); //215==Unpaid Leave - (UPL)
                                $rowData['status_id'] = $leave_record_exit->fh_leave_cat_type->m_id . '/' . $upLeave?->m_id;
                                $rowData['status'] = $leave_record_exit->fh_leave_cat_type->m_name . '/' . $upLeave?->m_name;
                                $rowData['status_code'] =  $leave_record_exit->fh_leave_cat_type->m_type . '/' . $upLeave?->m_type;
                                $rowData['statusColor'] =  json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($upLeave->m_other, true)['color'];
                                $rowData['presentCount']  = 0.5;
                                $rowData['absentCount'] = 0.5;
                            } else {
                                if (optional($leave_record_exit->fh_leave_day_segment)->m_id == 236) {
                                    $rowData['status_id'] = '-/' . $leave_record_exit->fh_leave_cat_type->m_id;
                                    $rowData['status'] = '-/' . $leave_record_exit->fh_leave_cat_type->m_name;
                                    $rowData['status_code'] =  '-/' . $leave_record_exit->fh_leave_cat_type->m_type;
                                    $rowData['statusColor'] =  '#BDBDBD/' . json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'];
                                    $rowData['presentCount']  = 0.5;
                                    $rowData['absentCount'] = 0.5;
                                }
                                if (optional($leave_record_exit->fh_leave_day_segment)->m_id == 235) {
                                    $rowData['status_id'] = $leave_record_exit->fh_leave_cat_type->m_id . '/-';
                                    $rowData['status'] = $leave_record_exit->fh_leave_cat_type->m_name . '/-';
                                    $rowData['status_code'] =  $leave_record_exit->fh_leave_cat_type->m_type . '/-';
                                    $rowData['statusColor'] =  json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'] . '/#BDBDBD';
                                    $rowData['presentCount']  = 0.5;
                                    $rowData['absentCount'] = 0.5;
                                }
                            }
                        } else {
                            $rowData['presentCount']  = 1; //if leave is full day & approved count as present
                            $rowData['status_id'] = $leave_record_exit->fh_leave_cat_type->m_id;
                            $rowData['status'] = $leave_record_exit->fh_leave_cat_type->m_name;
                            $rowData['status_code'] =  $leave_record_exit->fh_leave_cat_type->m_type;
                            $rowData['statusColor'] =  json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'];
                        }
                    } elseif (in_array($leave_record_exit->fh_leave_cat_type->m_id, [215]) && $rowData['isApproved']) { //215==Unpaid Leave - (UPL)
                        $is_found = 1;
                        if ($half_day_present) { // For half-day leave and half-day present
                            if ($leave_record_exit->fh_leave_day_segment->m_id == 236) {
                                $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id . '/' . $leave_record_exit->fh_leave_cat_type->m_id;
                                $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name . '/' . $leave_record_exit->fh_leave_cat_type->m_name;
                                $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type . '/' . $leave_record_exit->fh_leave_cat_type->m_type;
                                $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'] . '/' . json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'];
                            } elseif ($leave_record_exit->fh_leave_day_segment->m_id == 235) {
                                $rowData['status_id'] = $leave_record_exit->fh_leave_cat_type->m_id . '/' . $attendance_record_exit->fh_attendance_status->m_id;
                                $rowData['status'] = $leave_record_exit->fh_leave_cat_type->m_name . '/' . $attendance_record_exit->fh_attendance_status->m_name;
                                $rowData['status_code'] =  $leave_record_exit->fh_leave_cat_type->m_type . '/' . $attendance_record_exit->fh_attendance_status->m_type;
                                $rowData['statusColor'] = json_decode($leave_record_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
                            }
                            $rowData['absentCount'] = $leave_record_exit->fh_leave_day_type->m_id == 201 ? 1 : 0.5; //if UPL is full day & approved count as absent
                        } else {
                            $upLeave = MasterTable::where('m_id', 215)->first();
                            $rowData['status_id'] = $upLeave->m_id;
                            $rowData['status'] = $upLeave->m_name;
                            $rowData['status_code'] =  $upLeave->m_type;
                            $rowData['statusColor'] =  json_decode($upLeave->m_other, true)['color'];
                            $rowData['absentCount'] = $leave_record_exit->fh_leave_day_type->m_id == 201 ? 1 : 0.5; //if UPL is full day & approved count as absent
                        }
                    }

                    //Bifurcation of leave by leave type
                    $rowData[$leave_record_exit->fh_leave_cat_type->m_type] = $rowData['leaveCount'];
                    $rowData['UPL'] = $rowData['absentCount'];
                }
            }

            $attendance_exist = $attendance_record_exit && ($attendance_record_exit->atd_check_in_time || $attendance_record_exit->atd_check_out_time);

            if (is_null($is_found) || $attendance_exist) {
                $missedPunch =  AttendanceException::where('ae_b_id', $employee->emp_b_id)->where('ae_emp_id', $employee->emp_id)->where('ae_date', '=', $date)->first();
                if ($missedPunch) {
                    $missedPunchStatus = MasterTable::where('m_id', 228)->first(); //Missedpunch
                    $is_found = 1;
                    $rowData['missedPunchCount'] =  1;
                    $rowData['checkInTime'] = Carbon::createFromFormat('H:i:s', $missedPunch->ae_in_time)->format('h:i A');
                    $rowData['checkOutTime'] =  Carbon::createFromFormat('H:i:s', $missedPunch->ae_out_time)->format('h:i A');
                    $rowData['workingHour'] = number_format($missedPunch->ae_total_working, 2);
                    if ($missedPunch->ae_status != 170 && $missedPunch->ae_stage_completed) {

                        if ($attendance_record_exit && ($missedPunch->ae_out_time < optional($employee->fh_shift_type)->pst_end_time)) {
                            $rowData['presentCount']  = 0.5; //if missed punch  approved count as present
                            $rowData['status_id'] = $missedPunchStatus->m_id . '/' . $attendance_record_exit->fh_attendance_status->m_id;
                            $rowData['status'] =  $missedPunchStatus->m_name . '/' . $attendance_record_exit->fh_attendance_status->m_name;
                            $rowData['status_code'] =  $missedPunchStatus->m_type . '/' . $attendance_record_exit->fh_attendance_status->m_type;
                            $rowData['statusColor'] = json_decode($missedPunchStatus->m_other, true)['color'] . '/' . json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
                            $rowData['approvedMissedPunchCount'] = 0.5;
                        } else {
                            $rowData['presentCount']  = 1; //if missed punch  approved count as present
                            $presentData = MasterTable::where('m_id', 251)->select('m_id', 'm_name', 'm_type', 'm_other')->first();
                            $rowData['status_id'] = $presentData->m_id;
                            $rowData['status'] = $presentData->m_name;
                            $rowData['status_code'] = $presentData->m_type;
                            $rowData['statusColor'] = json_decode($presentData->m_other, true)['color'];
                            $rowData['approvedMissedPunchCount'] = 1;
                        }
                    } else {
                        $rowData['status_id'] = $missedPunchStatus->m_id;
                        $rowData['status'] =   $missedPunchStatus->m_name;
                        $rowData['status_code'] = $missedPunchStatus->m_type;
                        $rowData['statusColor'] = json_decode($missedPunchStatus->m_other, true)['color'];
                    }
                }
            }

            if (is_null($is_found)) {

                $holiday_record_exit =  PolicyHolidayList::where('phl_b_id', $employee->emp_b_id)->where('phl_start_date', '<=', $date)
                    ->where('phl_end_date', '>=', $date)
                    ->first();

                if ($holiday_record_exit) {
                    $holidayStatus = MasterTable::where('m_id', 321)->first();
                    $rowData['holidayCount'] = 1;
                    $is_found = 1;
                    $rowData['status'] = $holidayStatus->m_name;
                    $rowData['status_id'] = $holidayStatus->m_id;
                    $rowData['status_code'] = $holidayStatus->m_type;
                    $rowData['statusColor'] = json_decode($holidayStatus->m_other, true)['color'];
                    $rowData['checkInTime'] = '-';
                    $rowData['checkOutTime'] = '-';
                    $rowData['workingHour'] = '-';
                }
            }
            if (is_null($is_found)) {

                if (in_array($date, $weekOfDates)) {
                    $weekOffStatus = MasterTable::where('m_id', 322)->first();
                    $rowData['weekOffCount'] = 1;
                    $is_found = 1;
                    $rowData['status'] = $weekOffStatus->m_name;
                    $rowData['status_id'] = $weekOffStatus->m_id;
                    $rowData['status_code'] = $weekOffStatus->m_type;
                    $rowData['statusColor'] = json_decode($weekOffStatus->m_other, true)['color'];
                    $rowData['checkInTime'] = '-';
                    $rowData['checkOutTime'] = '-';
                    $rowData['workingHour'] = '-';
                }
            }
            if (is_null($is_found) && Carbon::parse($date)->isPast()) {
                $rowData['absentCount'] = 1;
                $rowData['status'] = $absentStatus->m_name;
                $rowData['status_id'] = $absentStatus->m_id;
                $rowData['status_code'] = $absentStatus->m_type;
                $rowData['statusColor'] = json_decode($absentStatus->m_other, true)['color'];
                $rowData['checkInTime'] = '-';
                $rowData['checkOutTime'] = '-';
                $rowData['workingHour'] = '-';
            }
            if ($rowData['status_id']) {
                $rowData['status_id'] = (string)$rowData['status_id'];
            }
        }
        return $rowData;
    }



    public static function getMonthlyAttendanceCount($employee, $year, $month, $weekOfDates)
    {
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();
        $dateRange = $startDate->toPeriod($endDate);

        // Step 1: Bulk Fetch All Data
        $attendanceRecords = $employee->attendance_record()
            ->whereBetween('atd_date', [$startDate, $endDate])
            ->with('fh_attendance_status')
            ->get()
            ->keyBy(function ($record) {
                return Carbon::parse($record->atd_date)->toDateString();
            });

        $missedPunches = AttendanceException::where('ae_emp_id', $employee->emp_id)
            ->whereBetween('ae_date', [$startDate, $endDate])
            ->get()
            ->keyBy(function ($row) {
                return Carbon::parse($row->ae_date)->toDateString();
            });

        $leaveRequests = $employee->leave_requests()
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('lvr_start_date', [$startDate, $endDate])
                    ->orWhereBetween('lvr_end_date', [$startDate, $endDate]);
            })
            ->with(['fh_leave_cat_type', 'fh_leave_day_type', 'fh_leave_day_segment'])
            ->get();

        $leaveMap = [];
        foreach ($leaveRequests as $leave) {
            $from = Carbon::parse($leave->lvr_start_date);
            $to = Carbon::parse($leave->lvr_end_date);
            foreach ($from->toPeriod($to) as $d) {
                $leaveMap[$d->toDateString()] = $leave;
            }
        }


        $holidays = PolicyHolidayList::where('phl_b_id', $employee->emp_b_id)
            ->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('phl_start_date', [$startDate, $endDate])
                    ->orWhereBetween('phl_end_date', [$startDate, $endDate]);
            })
            ->get()
            ->flatMap(function ($holiday) {
                return Carbon::parse($holiday->phl_start_date)
                    ->toPeriod(Carbon::parse($holiday->phl_end_date))
                    ->map(fn($date) => $date->toDateString());
            })
            ->toArray();

        // Step 2: Initialize Count
        $presentCount = 0;
        $absentCount = 0;
        $leaveCount = 0;
        $lateCount = 0;


        // Step 3: Loop through date range (in-memory operations only)
        foreach ($dateRange as $dateObj) {
            $date = $dateObj->toDateString();
            $attendance = $attendanceRecords[$date] ?? null;
            $missedPunch = $missedPunches[$date] ?? null;
            $leave = $leaveMap[$date] ?? null;
            $isHoliday = in_array($date, $holidays);
            $isWeekOff = in_array($date, $weekOfDates);

            if ($attendance) {
                if ($attendance->atd_attendance_status == 251) $presentCount++;
                elseif ($attendance->atd_attendance_status == 252) {
                    $presentCount += 0.5;
                }
                if ($attendance->atd_is_late) $lateCount++;
            } elseif ($missedPunch && $missedPunch->ae_status != 170 && $missedPunch->ae_stage_completed) {
                if ($missedPunch->ae_out_time < optional($employee->fh_shift_type)->pst_end_time) {
                    $presentCount += 0.5;
                } else {
                    $presentCount++;
                }
            } elseif ($leave && $leave->lvr_status != 170 && $leave->lvr_stage_completed) {
                $leaveCount += ($leave->fh_leave_day_type->m_id == 201 ? 1 : 0.5);
                $presentCount += ($leave->fh_leave_day_type->m_id == 201 ? 1 : 0.5); // if counted as present
            } elseif ($isHoliday || $isWeekOff) {
                // skip
            } else {
                if ($dateObj->isPast()) {
                    $absentCount++;
                }
            }
        }

        return [
            'presentCount' => $presentCount,
            'absentCount' => $absentCount,
            'leaveCount' => $leaveCount,
            'lateCount' => $lateCount,
        ];
    }




    public static function getWeekOffDates($employee, $year = NULL, $month = NULL, $startDate = NULL, $endDate = NULL)
    {

        $instance = new self();
        $weekOfDates = [];
        if (isset($employee->fh_week_off_policy) && $employee->fh_week_off_policy) {


            if ($startDate && $endDate) {
                $occurrences = $instance->getWeekDaysInDateRange($startDate, $endDate);
            } else {
                $occurrences = $instance->getOccurrencesOfDaysInMonth($year, $month);
            }
            $weekDays = $employee->fh_week_off_policy->getWeek(
                json_decode($employee->fh_week_off_policy->pwo_recurrence_day_ids)
            );

            foreach ($occurrences as $key => $dates) {
                if (isset($weekDays[$key])) {
                    foreach ($weekDays[$key] as $wd) {
                        $nthDay = (int) filter_var($wd, FILTER_SANITIZE_NUMBER_INT);
                        if (isset($dates[$nthDay - 1])) {
                            $weekOfDates[] = $dates[$nthDay - 1];
                        }
                    }
                }
            }
        }
        return $weekOfDates;
    }

    public static function getWeekOffDatesInRange($employee, $startDate, $endDate)
    {
        $instance = new self();
        $weekOffDates = [];

        if (isset($employee->fh_week_off_policy) && $employee->fh_week_off_policy) {
            // Convert start and end dates to Carbon instances
            $startDate = Carbon::parse($startDate);
            $endDate = Carbon::parse($endDate);

            // Get all occurrences of days between the start and end dates
            $occurrences = $instance->getOccurrencesOfDaysInRange($startDate, $endDate);

            // Get the week-off days from the employee's policy
            $weekDays = $employee->fh_week_off_policy->getWeek(
                json_decode($employee->fh_week_off_policy->pwo_recurrence_day_ids)
            );

            dd($weekDays);

            foreach ($occurrences as $dayOfWeek => $dates) {
                if (isset($weekDays[$dayOfWeek])) {
                    foreach ($weekDays[$dayOfWeek] as $wd) {
                        $nthDay = (int) filter_var($wd, FILTER_SANITIZE_NUMBER_INT);
                        if (isset($dates[$nthDay - 1])) {
                            $weekOffDates[] = $dates[$nthDay - 1];
                        }
                    }
                }
            }
        }

        return $weekOffDates;
    }
    private function getOccurrencesOfDaysInRange(string $startDate, string $endDate): array
    {
        $occurrences = [];

        // Initialize array for each day of the week
        $weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        foreach ($weekDays as $day) {
            $occurrences[$day] = [];
        }

        // Convert start and end dates to Carbon instances
        $start = Carbon::parse($startDate);
        $end = Carbon::parse($endDate);
        $currentDate = $start->copy();

        // Iterate through all dates in the range
        while ($currentDate->lte($end)) {
            $dayName = $currentDate->format('l'); // Get the full day name (e.g., Sunday, Monday)
            $occurrences[$dayName][] = $currentDate->toDateString();
            $currentDate->addDay(); // Move to the next day
        }

        return $occurrences;
    }




    private function getOccurrencesOfDaysInMonth(int $year, int $month): array
    {
        $daysInMonth = Carbon::create($year, $month)->daysInMonth;
        $occurrences = [];

        // Initialize array for each day of the week
        $weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        foreach ($weekDays as $day) {
            $occurrences[$day] = [];
        }

        \Log::info('Test: ' . $daysInMonth);

        // Iterate through all days in the month
        for ($day = 1; $day <= $daysInMonth; $day++) {
            $date = Carbon::create($year, $month, $day);
            $dayName = $date->format('l'); // Get the full day name (e.g., Sunday, Monday)
            $occurrences[$dayName][] = $date->toDateString();
        }

        return $occurrences;
    }

    private function getWeekDaysInDateRange($startDate, $endDate)
    {
        $startDate = Carbon::parse($startDate);
        $endDate = Carbon::parse($endDate);
        $occurrences = [];

        // Initialize array for each day of the week
        $weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        foreach ($weekDays as $day) {
            $occurrences[$day] = [];
        }
        // dd('inside this 2',$startDate, $endDate,$occurrences);
        while ($startDate->lte($endDate)) {
            \Log::info('inside this 1' . $startDate . ' || ' . $endDate);
            $dayName = $startDate->format('l'); // Get the full day name (e.g., Sunday, Monday)
            $occurrences[$dayName][] = $startDate->toDateString();
            $startDate->addDay(); // Properly increment Carbon date
            \Log::info('inside this 2' . $startDate . ' || ' . $endDate);
        }
        return $occurrences;
    }

    public static function getBreadcrumbs()
    {
        $segments = FacadesRequest::segments(); // Get URL segments
        $breadcrumbs = [];

        // Add "Dashboard" as the first breadcrumb
        $breadcrumbs[] = [
            'title' => 'Dashboard',
            'url' => url('/dashboard'),
        ];

        // Loop through URL segments and create breadcrumbs
        $path = '';
        foreach ($segments as $segment) {
            $path .= '/' . $segment;
            $breadcrumbs[] = [
                'title' => ucfirst(str_replace('-', ' ', $segment)), // Format title
                'url' => url($path),
            ];
        }

        return $breadcrumbs;
    }

    public static function alpha_numeric_generator($num, $const = '', $prefix_id = '', $ref_id = '', $prefix_char = '')
    {
        if ($ref_id != '' || $ref_id != null || !isset($ref_id)) {
            if ($const != '')
                $ref_id = explode($const, $ref_id)[1];
            $match = preg_split('/([A-Za-z]+)/', $ref_id, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
            $match[1] = substr($match[1], -$num);
            if ($match[1] != str_repeat(9, $num)) {
                $match[1]++;
            } else {
                $match[0]++;
                $match[1] = 1;
            }
            $result = $const . $match[0] . $prefix_id . str_pad($match[1], $num, 0, STR_PAD_LEFT);
        } else {
            if ($prefix_char == '') {
                $result = $const . 'AA' . $prefix_id . str_pad(1, $num, 0, STR_PAD_LEFT);
            } else {
                $result = $const . $prefix_char . $prefix_id . str_pad(1, $num, 0, STR_PAD_LEFT);
            }
        }

        return $result;
    }

    public static function send_mail($email, $mailable)
    {
        return true; //this is temporary because mail is not working currently remove this line when resolved to execute the below code
        return Mail::to($email)->send($mailable);
    }

    public static function sendCustomEmail($templateType, array $placeholders, $recipientEmail, $businessId, $attachment = null)
    {
        return true; //this is temporary because mail is not working currently remove this line when resolved to execute the below code

        // Retrieve the mail template based on type and business ID
        $template = MailTemplate::where('mt_mail_type', $templateType)->where('mt_b_id', $businessId)->first();
        if (!$template) {
            $template = MailTemplate::where('mt_mail_type', $templateType)->first();
        }

        // If no template found, return false
        if (!$template) {
            return false;
        }

        // Replace placeholders in the email body and subject
        $mailBody = str_replace(array_keys($placeholders), array_values($placeholders), $template->mt_body);
        $mailSubject = str_replace(array_keys($placeholders), array_values($placeholders), $template->mt_title);

        // Send the email
        Mail::send([], [], function ($message) use ($recipientEmail, $mailSubject, $mailBody, $attachment) {
            $message->to($recipientEmail)
                ->subject($mailSubject)
                ->html($mailBody);
            if ($attachment) {
                // If it's a file path (e.g., from storage), attach the file
                $message->attach($attachment['path'], [
                    'as' => $attachment['name'], // Optional: specify a custom file name for the attachment
                    'mime' => $attachment['mime'], // Optional: specify MIME type, e.g., 'application/pdf'
                ]);
            }
        });

        return true;
    }

    public static function encrypt_or_decrypt($key, $type = 'encrypt')
    {
        $value = '';
        if ($type == 'decrypt') {
            $value = Crypt::decryptString($key);
        } else {
            $value =  Crypt::encryptString($key);
        }
        return $value;
    }

    // public static function newGetMonthlyAttendanceDetails($employee, $month, $year, $holiday_record_exits, $weekOfDates)
    // {

    //     $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
    //     $endDate = $startDate->copy()->endOfMonth();
    //     $dateRange = $startDate->toPeriod($endDate);

    //     $absentStatus = MasterTable::where('m_id', 203)->first();


    //     // Preload everything to avoid repeated DB hits
    //     $attendanceRecords = $employee->attendance_record()
    //         ->whereBetween('atd_date', [$startDate, $endDate])
    //         ->get()
    //         ->keyBy(fn($row) => Carbon::parse($row->atd_date)->toDateString());

    //     $attendanceLogs = AttendanceLog::where('al_emp_id', $employee->emp_id)
    //         ->whereBetween('al_date', [$startDate, $endDate])
    //         ->get()
    //         ->keyBy(fn($row) => Carbon::parse($row->al_date)->toDateString());


    //     $missedPunches = AttendanceException::where('ae_b_id', $employee->emp_b_id)
    //         ->where('ae_emp_id', $employee->emp_id)
    //         ->whereBetween('ae_date', [$startDate, $endDate])
    //         ->get()
    //         ->keyBy(fn($row) => Carbon::parse($row->ae_date)->toDateString());


    //     $leave_record_exits = $employee->leave_requests()->where(function ($q) use ($startDate, $endDate) {
    //         $q->whereBetween('lvr_start_date', [$startDate, $endDate])
    //             ->orWhereBetween('lvr_end_date', [$startDate, $endDate]);
    //     })->get();

    //     $leaveByDate = collect();

    //     foreach ($leave_record_exits as $leave) {
    //         $start = Carbon::parse($leave->lvr_start_date);
    //         $end = Carbon::parse($leave->lvr_end_date);

    //         while ($start->lte($end)) {
    //             // $leaveByDate->put($start->toDateString(), $leave);
    //             // $start->addDay();

    //             $dateStr = $start->toDateString();
    //             if (!$leaveByDate->has($dateStr)) {
    //                 $leaveByDate->put($dateStr, collect());
    //             }
    //             $leaveByDate->get($dateStr)->push($leave);
    //             $start->addDay();
    //         }
    //     }


    //     $leave_record_exits = $leaveByDate;

    //     $attendanceData = [];
    //     foreach ($dateRange as $dateObj) {
    //         $date = $dateObj->toDateString();
    //         $is_found = null;
    //         $rowData = [
    //             'status' => '-',
    //             'status_id' => '-',
    //             'status_code' => '-',
    //             'statusColor' => '#BDBDBD',
    //             'checkInTime' => null,
    //             'checkOutTime' => null,
    //             'updatedBy' => null,
    //             'workingHour' => null,
    //             'OT' => null,
    //             'earlyExit' => null,
    //             'late' => null,
    //             'attendance_remark' => '--',
    //             'checkInLocation' => '--',
    //             'checkOutLocation' => '--',
    //             'checkInPhoto' => [],
    //             'checkOutPhoto' => [],
    //             'atd_segments' => [],
    //             'presentCount' => 0,
    //             'leaveCount' => 0,
    //             'holidayCount' => 0,
    //             'weekOffCount' => 0,
    //             'absentCount' => 0,
    //             'halfDayCount' => 0,
    //             'missedPunchCount' => 0,
    //             'overtimeCount' => 0,
    //             'lateCount' => 0,
    //             'earlyExitCount' => 0,
    //             'approvedLeaveCount' => 0,
    //             'approvedMissedPunchCount' => 0,
    //             'isApproved' => null,
    //             'previousCheckInTime' => null,
    //             'previousCheckOutTime' => null,
    //             'previousLate' => null,
    //             'previousExit' => null,
    //             'UPL' => 0,
    //         ];
    //         if ($employee->emp_date_of_joining <= $date) {


    //             $attendance_record_exit = $attendanceRecords[$date] ?? null;
    //             $attendance_log = $attendanceLogs[$date] ?? null;
    //             $missedPunch = $missedPunches[$date] ?? null;
    //             $holiday_record_exit = $holiday_record_exits[$date] ?? null;

    //             // $leave_record_exit = $leave_record_exits[$date] ?? null;
    //             $leave_record_exit = $leave_record_exits->get($date) ?? null;


    //             $is_found = null;

    //             if ($attendance_record_exit && $attendance_record_exit->fh_attendance_status) {

    //                 if ($attendance_record_exit->atd_attendance_status == 252) { //Half Day
    //                     $rowData['halfDayCount'] = 1;
    //                     $rowData['presentCount']  = 0.5;
    //                     $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
    //                     $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
    //                     $is_found = 1;
    //                 } else {
    //                     if (!$missedPunch) {
    //                         $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
    //                         $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
    //                         if ($attendance_record_exit->atd_attendance_status == 251) {
    //                             $rowData['presentCount'] = 1; //Present
    //                         }
    //                     }
    //                     $is_found = 1;
    //                 }

    //                 if ($attendance_record_exit->atd_is_overtime == 1) {
    //                     $rowData['overtimeCount'] = 1;
    //                 }

    //                 if ($attendance_record_exit->atd_is_late == 1) {
    //                     $rowData['lateCount'] = 1;
    //                 }

    //                 if ($attendance_record_exit->atd_is_early_exit == 1) {
    //                     $rowData['earlyExitCount'] = 1;
    //                 }

    //                 $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name;
    //                 $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
    //                 $rowData['checkInTime'] = $attendance_record_exit->atd_check_in_time ? Carbon::parse($attendance_record_exit->atd_check_in_time)->format('h:i A') : '-';
    //                 $rowData['checkOutTime'] = $attendance_record_exit->atd_check_out_time ? Carbon::parse($attendance_record_exit->atd_check_out_time)->format('h:i A') :  '-';
    //                 $rowData['workingHour'] = $attendance_record_exit->atd_total_worked_hours ? number_format($attendance_record_exit->atd_total_worked_hours, 2) : '-';
    //                 $rowData['earlyExit'] = ($attendance_record_exit->atd_is_early_exit && $attendance_record_exit->atd_early_exit_duration) ? number_format($attendance_record_exit->atd_early_exit_duration, 2) :  null;
    //                 $rowData['late'] = ($attendance_record_exit->atd_is_late && $attendance_record_exit->atd_late_duration) ? number_format($attendance_record_exit->atd_late_duration, 2) :  null;
    //                 $rowData['OT'] = ($attendance_record_exit->atd_is_overtime && $attendance_record_exit->atd_overtime_hours) ? number_format($attendance_record_exit->atd_overtime_hours, 2) :  null;
    //                 $rowData['attendance_remark'] = $attendance_record_exit->atd_remark  ? $attendance_record_exit->atd_remark :  '-';
    //                 $rowData['checkInLocation'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_location ? $attendance_record_exit->atd_punchin_location : '--';
    //                 $rowData['checkOutLocation'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_location ? $attendance_record_exit->atd_punchout_location : '--';
    //                 $rowData['checkInPhoto'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_photo ? json_decode($attendance_record_exit->atd_punchin_photo) : [];
    //                 $rowData['checkOutPhoto'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_photo ? json_decode($attendance_record_exit->atd_punchout_photo) : [];
    //                 $rowData['atd_segments'] =  $attendance_record_exit && $attendance_record_exit->atd_segments ? [json_decode($attendance_record_exit->atd_segments)] : [];
    //                 $rowData['updatedBy'] = $attendance_record_exit->updated_by  ? $attendance_record_exit->updated_by->emp_full_name :  '-';
    //                 if ($attendance_log) {
    //                     $rowData['previousCheckInTime'] = $attendance_log->al_check_in_time ? Carbon::parse($attendance_log->al_check_in_time)->format('h:i A') : '-';
    //                     $rowData['previousCheckOutTime'] = $attendance_log->al_check_out_time ? Carbon::parse($attendance_log->al_check_out_time)->format('h:i A') :  '-';
    //                     $rowData['previousLate'] = ($attendance_log->al_is_late && $attendance_log->al_late_duration) ? number_format($attendance_log->al_late_duration, 2) : null;
    //                     $rowData['previousExit'] = ($attendance_log->al_is_early_exit && $attendance_log->al_early_exit_duration) ? number_format($attendance_log->al_early_exit_duration, 2) : null;
    //                 }
    //             }


    //             $half_day_present = ($attendance_record_exit && $attendance_record_exit->atd_attendance_status == 252); //252==Half Day
    //             if (is_null($is_found) || $half_day_present) {

    //                 if ($leave_record_exit && $leave_record_exit->count() == 1) {
    //                     $lvr_exit = $leave_record_exit->first();
    //                     if ($lvr_exit->fh_leave_day_type->m_id == 201) {
    //                         $rowData['leaveCount'] = 1;
    //                         if ($lvr_exit->lvr_status != 170 && $lvr_exit->lvr_stage_completed && $lvr_exit->fh_leave_cat_type->m_id != 215) {
    //                             $rowData['approvedLeaveCount'] = 1;
    //                         }
    //                     } else {
    //                         $rowData['leaveCount'] = 0.5;
    //                         if ($lvr_exit->lvr_status != 170 && $lvr_exit->lvr_stage_completed && $lvr_exit->fh_leave_cat_type->m_id != 215) {
    //                             $rowData['approvedLeaveCount'] = 0.5;
    //                         }
    //                     }

    //                     $rowData['isApproved'] = ($lvr_exit->lvr_status != 170 && $lvr_exit->lvr_stage_completed);
    //                     $leave_category_ids = MasterTable::where('m_group', 'LEAVE_CATEGORY')->pluck('m_id')->toArray();

    //                     if (in_array($lvr_exit->fh_leave_cat_type->m_id, $leave_category_ids) && $rowData['isApproved']) {
    //                         $is_found = 1;
    //                         if ($half_day_present) { // For half-day leave and half-day present
    //                             if ($lvr_exit->fh_leave_day_segment->m_id == 236) {
    //                                 $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id . '/' . $lvr_exit->fh_leave_cat_type->m_id;
    //                                 $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name . '/' . $lvr_exit->fh_leave_cat_type->m_name;
    //                                 $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type . '/' . $lvr_exit->fh_leave_cat_type->m_type;
    //                                 $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'] . '/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
    //                             } elseif ($lvr_exit->fh_leave_day_segment->m_id == 235) {
    //                                 $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $attendance_record_exit->fh_attendance_status->m_id;
    //                                 $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $attendance_record_exit->fh_attendance_status->m_name;
    //                                 $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/' . $attendance_record_exit->fh_attendance_status->m_type;
    //                                 $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
    //                             }
    //                             $rowData['presentCount'] += 0.5; // from attendance
    //                             if ($lvr_exit->fh_leave_cat_type->m_id != 215) { // Not UPL
    //                                 $rowData['presentCount'] += 0.5; // from approved CL
    //                             } else {
    //                                 $rowData['absentCount'] += 0.5; // UPL remains absent
    //                             }
    //                             // $rowData['presentCount']  = $rowData['presentCount'] + 0.5; //if half day leave & approved count as half present
    //                         } elseif ($lvr_exit->lvr_total_leave_days == 0.5) { //This case addresses situations where the leave balance is 0.5, but the leave applied exceeds 0.5.
    //                             if (Carbon::parse($date)->format('Y-m-d') < now()->format('Y-m-d')) {
    //                                 $upLeave = MasterTable::where('m_id', 215)->first(); //215==Unpaid Leave - (UPL)
    //                                 $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $upLeave?->m_id;
    //                                 $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $upLeave?->m_name;
    //                                 $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/' . $upLeave?->m_type;
    //                                 $rowData['statusColor'] =  json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($upLeave->m_other, true)['color'];
    //                                 $rowData['presentCount']  = 0.5;
    //                                 $rowData['absentCount'] = 0.5;
    //                             } else {
    //                                 if (optional($lvr_exit->fh_leave_day_segment)->m_id == 236) {
    //                                     $rowData['status_id'] = '-/' . $lvr_exit->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = '-/' . $lvr_exit->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] =  '-/' . $lvr_exit->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] =  '#BDBDBD/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
    //                                     $rowData['presentCount']  = 0.5;
    //                                     $rowData['absentCount'] = 0.5;
    //                                 }
    //                                 if (optional($lvr_exit->fh_leave_day_segment)->m_id == 235) {
    //                                     $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/-';
    //                                     $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/-';
    //                                     $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/-';
    //                                     $rowData['statusColor'] =  json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/#BDBDBD';
    //                                     $rowData['presentCount']  = 0.5;
    //                                     $rowData['absentCount'] = 0.5;
    //                                 }
    //                             }
    //                         } else {
    //                             $rowData['presentCount']  = 1; //if leave is full day & approved count as present
    //                             $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id;
    //                             $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name;
    //                             $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type;
    //                             $rowData['statusColor'] =  json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
    //                         }
    //                     } elseif (in_array($lvr_exit->fh_leave_cat_type->m_id, [215])) { //215==Unpaid Leave - (UPL)
    //                         $is_found = 1;
    //                         if ($half_day_present) { // For half-day leave and half-day present
    //                             if ($lvr_exit->fh_leave_day_segment->m_id == 236) {
    //                                 $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id . '/' . $lvr_exit->fh_leave_cat_type->m_id;
    //                                 $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name . '/' . $lvr_exit->fh_leave_cat_type->m_name;
    //                                 $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type . '/' . $lvr_exit->fh_leave_cat_type->m_type;
    //                                 $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'] . '/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
    //                             } elseif ($lvr_exit->fh_leave_day_segment->m_id == 235) {
    //                                 $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $attendance_record_exit->fh_attendance_status->m_id;
    //                                 $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $attendance_record_exit->fh_attendance_status->m_name;
    //                                 $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/' . $attendance_record_exit->fh_attendance_status->m_type;
    //                                 $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
    //                             }
    //                             $rowData['absentCount'] = $lvr_exit->fh_leave_day_type->m_id == 201 ? 1 : 0.5; //if UPL is full day & approved count as absent
    //                         } else {
    //                             $upLeave = MasterTable::where('m_id', 215)->first();
    //                             $rowData['status_id'] = $upLeave->m_id;
    //                             $rowData['status'] = $upLeave->m_name;
    //                             $rowData['status_code'] =  $upLeave->m_type;
    //                             $rowData['statusColor'] =  json_decode($upLeave->m_other, true)['color'];
    //                             $rowData['absentCount'] = $lvr_exit->fh_leave_day_type->m_id == 201 ? 1 : 0.5; //if UPL is full day & approved count as absent
    //                         }
    //                     }

    //                     //Bifurcation of leave by leave type
    //                     $rowData[$lvr_exit->fh_leave_cat_type->m_type] = $rowData['leaveCount'];
    //                     $rowData['UPL'] = $rowData['absentCount'];
    //                 }elseif($leave_record_exit && $leave_record_exit->count() == 2){// this case is for 2 leave applied on same day first half day and second full day

    //                     $rowData['leaveCount'] = 0;
    //                     $rowData['approvedLeaveCount'] = 0;
    //                     $rowData['isApproved'] = 0;
    //                     $rowData['presentCount'] = 0;
    //                     $rowData['absentCount'] = 0;

    //                     $is_found = 1;
    //                     $first = true;
    //                     $leaveCounter = 0;

    //                     foreach($leave_record_exit as $lr){
    //                         $leaveCounter++;
    //                         $rowData['leaveCount'] += 0.5;
    //                         // $rowData['absentCount'] += 0.5;
    //                         // if ($lr->lvr_status != 170 && $lr->lvr_stage_completed) {
    //                         //      if($lr->fh_leave_cat_type->m_id != 215)
    //                         //      {
    //                         //         $rowData['approvedLeaveCount'] += 0.5;
    //                         //      }
    //                         //      $rowData['isApproved'] = 1;
    //                         // }

    //                         // ✅ Updated leave and attendance logic

    //                         $rowData['leaveCount'] += 0.5;
    //                         if ($lr->lvr_status != 170 && $lr->lvr_stage_completed) {
    //                             $rowData['isApproved'] = 1; // ✅ Mark overall isApproved if any is approved

    //                             if ($lr->fh_leave_cat_type->m_id != 215) {
    //                                 $rowData['approvedLeaveCount'] += 0.5;
    //                                 $rowData['presentCount'] += 0.5; // ✅ Approved and not UPL => Present
    //                             } else {
    //                                 $rowData['absentCount'] += 0.5; // ✅ UPL is still absent even if approved
    //                             }
    //                         } else {
    //                             $rowData['absentCount'] += 0.5; // ✅ Unapproved leave => Absent
    //                         }

    //                         $leave_category_ids = MasterTable::where('m_group', 'LEAVE_CATEGORY')->pluck('m_id')->toArray();
    //                         if (in_array($lr->fh_leave_cat_type->m_id, $leave_category_ids) && $rowData['isApproved']) {
    //                             if (Carbon::parse($date)->format('Y-m-d') < now()->format('Y-m-d')) {
    //                                 if(optional($lr->fh_leave_day_segment)->m_id == 235){ //235==First Half
    //                                     $rowData['status_id'] = $lr->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = $lr->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] =  $lr->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] =  json_decode($lr->fh_leave_cat_type->m_other, true)['color'];
    //                                 }elseif(optional($lr->fh_leave_day_segment)->m_id == 236){ //236==Second Half
    //                                     $rowData['status_id'] = $rowData['status_id']. '/' . $lr->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = $rowData['status'] . '/' . $lr->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] = $rowData['status_code'] . '/' . $lr->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] = $rowData['statusColor'] . '/' . json_decode($lr->fh_leave_cat_type->m_other, true)['color'];
    //                                 }
    //                             }

    //                         } elseif (in_array($lr->fh_leave_cat_type->m_id, [215])) { //215==Unpaid Leave - (UPL)
    //                              if (Carbon::parse($date)->format('Y-m-d') < now()->format('Y-m-d')) {
    //                                 if(optional($lr->fh_leave_day_segment)->m_id == 235){ //235==First Half
    //                                     $rowData['status_id'] = $lr->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = $lr->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] =  $lr->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] =  json_decode($lr->fh_leave_cat_type->m_other, true)['color'];
    //                                 }elseif(optional($lr->fh_leave_day_segment)->m_id == 236){ //236==Second Half
    //                                     $rowData['status_id'] = $rowData['status_id']. '/' . $lr->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = $rowData['status'] . '/' . $lr->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] = $rowData['status_code'] . '/' . $lr->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] = $rowData['statusColor'] . '/' . json_decode($lr->fh_leave_cat_type->m_other, true)['color'];
    //                                 }
    //                             }
    //                         }
    //                         $rowData[$lr->fh_leave_cat_type->m_type] = $rowData['leaveCount'];
    //                         $rowData['UPL'] = $rowData['absentCount'];
    //                     }


    //                 }
    //             }

    //             $attendance_exist = $attendance_record_exit && ($attendance_record_exit->atd_check_in_time || $attendance_record_exit->atd_check_out_time);

    //             if (is_null($is_found) || $attendance_exist) {
    //                 if ($missedPunch) {
    //                     $missedPunchStatus = MasterTable::where('m_id', 228)->first(); //Missedpunch
    //                     $is_found = 1;
    //                     $rowData['missedPunchCount'] =  1;
    //                     $rowData['checkInTime'] = Carbon::createFromFormat('H:i:s', $missedPunch->ae_in_time)->format('h:i A');
    //                     $rowData['checkOutTime'] =  Carbon::createFromFormat('H:i:s', $missedPunch->ae_out_time)->format('h:i A');
    //                     $rowData['workingHour'] = number_format($missedPunch->ae_total_working, 2);
    //                     if ($missedPunch->ae_status != 170 && $missedPunch->ae_stage_completed) {
    //                          $shiftStartTime = date('Y-m-d', strtotime($date)) . ' ' . $employee->fh_shift_type->pst_start_time;
    //                             $shiftEndTime = date('Y-m-d', strtotime($date)) . ' ' . $employee->fh_shift_type->pst_end_time;

    //                             $pst_start_time = Carbon::parse($shiftStartTime);
    //                             $pst_end_time = Carbon::parse($shiftEndTime);
    //                             $dailyWorkingHours = $pst_start_time->diffInMinutes($pst_end_time);

    //                             $checkInTime = Carbon::parse($date . ' ' . $missedPunch->ae_in_time);
    //                             $checkOutTime =  Carbon::parse($date . ' ' . $missedPunch->ae_out_time);
    //                             $workedDuration = $checkInTime->diffInMinutes($checkOutTime);
    //                             $fullDayThreshold = $dailyWorkingHours;
    //                             $halfDayThreshold = $dailyWorkingHours / 2;
    //                         if($workedDuration >= $fullDayThreshold){
    //                             $rowData['presentCount']  = 1; //if missed punch  approved count as present
    //                             $presentData = MasterTable::where('m_id', 251)->select('m_id', 'm_name', 'm_type', 'm_other')->first();
    //                             $rowData['status_id'] = $presentData->m_id;
    //                             $rowData['status'] = $presentData->m_name;
    //                             $rowData['status_code'] = $presentData->m_type;
    //                             $rowData['statusColor'] = json_decode($presentData->m_other, true)['color'];
    //                             $rowData['approvedMissedPunchCount'] = 0.5;

    //                         } else if ($workedDuration >= $halfDayThreshold) { //half day present & half day leave case
    //                             $halfDayPresentData = MasterTable::where('m_id', 252)->select('m_id', 'm_name', 'm_type', 'm_other')->first();
    //                             if ($leave_record_exit && $leave_record_exit->count() == 1) {
    //                                 $lvr_exit = $leave_record_exit->first();
    //                                 if (optional($lvr_exit->fh_leave_day_segment)->m_id == 236) {
    //                                     $rowData['status_id'] = $halfDayPresentData->m_id . '/' . $lvr_exit->fh_leave_cat_type->m_id;
    //                                     $rowData['status'] = $halfDayPresentData->m_name . '/' . $lvr_exit->fh_leave_cat_type->m_name;
    //                                     $rowData['status_code'] = $halfDayPresentData->m_type . '/' . $lvr_exit->fh_leave_cat_type->m_type;
    //                                     $rowData['statusColor'] = json_decode($halfDayPresentData->m_other, true)['color'] . '/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
    //                                 } elseif (optional($lvr_exit->fh_leave_day_segment)->m_id == 235) {
    //                                     $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $halfDayPresentData->m_id;
    //                                     $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $halfDayPresentData->m_name;
    //                                     $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/' . $halfDayPresentData->m_type;
    //                                     $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($halfDayPresentData->m_other, true)['color'];
    //                                 }
    //                             }
    //                         }
    //                     } else {
    //                         $rowData['status_id'] = $missedPunchStatus->m_id;
    //                         $rowData['status'] =   $missedPunchStatus->m_name;
    //                         $rowData['status_code'] = $missedPunchStatus->m_type;
    //                         $rowData['statusColor'] = json_decode($missedPunchStatus->m_other, true)['color'];
    //                     }
    //                 }
    //             }

    //             if (is_null($is_found)) {


    //                 if ($holiday_record_exit) {
    //                     $holidayStatus = MasterTable::where('m_id', 321)->first();
    //                     $rowData['holidayCount'] = 1;
    //                     $is_found = 1;
    //                     $rowData['status'] = $holidayStatus->m_name;
    //                     $rowData['status_id'] = $holidayStatus->m_id;
    //                     $rowData['status_code'] = $holidayStatus->m_type;
    //                     $rowData['statusColor'] = json_decode($holidayStatus->m_other, true)['color'];
    //                     $rowData['checkInTime'] = '-';
    //                     $rowData['checkOutTime'] = '-';
    //                     $rowData['workingHour'] = '-';
    //                 }
    //             }
    //             if (is_null($is_found)) {

    //                 if (in_array($date, $weekOfDates)) {
    //                     $weekOffStatus = MasterTable::where('m_id', 322)->first();
    //                     $rowData['weekOffCount'] = 1;
    //                     $is_found = 1;
    //                     $rowData['status'] = $weekOffStatus->m_name;
    //                     $rowData['status_id'] = $weekOffStatus->m_id;
    //                     $rowData['status_code'] = $weekOffStatus->m_type;
    //                     $rowData['statusColor'] = json_decode($weekOffStatus->m_other, true)['color'];
    //                     $rowData['checkInTime'] = '-';
    //                     $rowData['checkOutTime'] = '-';
    //                     $rowData['workingHour'] = '-';
    //                 }
    //             }
    //             if (is_null($is_found) && Carbon::parse($date)->isPast()) {
    //                 $rowData['absentCount'] = 1;
    //                 $rowData['status'] = $absentStatus->m_name;
    //                 $rowData['status_id'] = $absentStatus->m_id;
    //                 $rowData['status_code'] = $absentStatus->m_type;
    //                 $rowData['statusColor'] = json_decode($absentStatus->m_other, true)['color'];
    //                 $rowData['checkInTime'] = '-';
    //                 $rowData['checkOutTime'] = '-';
    //                 $rowData['workingHour'] = '-';
    //             }
    //             if ($rowData['status_id']) {
    //                 $rowData['status_id'] = (string)$rowData['status_id'];
    //             }
    //             $rowData['date'] = $date;
    //             $attendanceData[] = $rowData;
    //         }
    //     }
    //     return $attendanceData;
    // }


    public static function newGetMonthlyAttendanceDetails($employee, $month, $year, $holiday_record_exits, $weekOfDates)
    {
        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();
        $dateRange = $startDate->toPeriod($endDate);

        $absentStatus = MasterTable::where('m_id', 203)->first();


        // Preload everything to avoid repeated DB hits
        $attendanceRecords = $employee->attendance_record()
        ->whereBetween('atd_date', [$startDate, $endDate])
            ->get()
            ->keyBy(fn($row) => Carbon::parse($row->atd_date)->toDateString());

            $attendanceLogs = AttendanceLog::where('al_emp_id', $employee->emp_id)
            ->whereBetween('al_date', [$startDate, $endDate])
            ->get()
            ->keyBy(fn($row) => Carbon::parse($row->al_date)->toDateString());

            $missedPunches = AttendanceException::where('ae_b_id', $employee->emp_b_id)
            ->where('ae_emp_id', $employee->emp_id)
            ->whereBetween('ae_date', [$startDate, $endDate])
            ->get()
            ->keyBy(fn($row) => Carbon::parse($row->ae_date)->toDateString());


            $leave_record_exits = $employee->leave_requests()->where(function ($q) use ($startDate, $endDate) {
                $q->whereBetween('lvr_start_date', [$startDate, $endDate])
                ->orWhereBetween('lvr_end_date', [$startDate, $endDate]);
            })->get();

            $leaveByDate = collect();

            foreach ($leave_record_exits as $leave) {
                $start = Carbon::parse($leave->lvr_start_date);
                $end = Carbon::parse($leave->lvr_end_date);

                while ($start->lte($end)) {
                    // $leaveByDate->put($start->toDateString(), $leave);
                    // $start->addDay();

                    $dateStr = $start->toDateString();
                    if (!$leaveByDate->has($dateStr)) {
                        $leaveByDate->put($dateStr, collect());
                    }
                    $leaveByDate->get($dateStr)->push($leave);
                    $start->addDay();
                }
            }


            $leave_record_exits = $leaveByDate;

            $attendanceData = [];
            foreach ($dateRange as $dateObj) {
            $date = $dateObj->toDateString();
            $is_found = null;
            $rowData = [
                'status' => '-',
                'status_id' => '-',
                'status_code' => '-',
                'statusColor' => '#BDBDBD',
                'checkInTime' => null,
                'checkOutTime' => null,
                'updatedBy' => null,
                'workingHour' => null,
                'OT' => null,
                'earlyExit' => null,
                'late' => null,
                'attendance_remark' => '--',
                'checkInLocation' => '--',
                'checkOutLocation' => '--',
                'checkInPhoto' => [],
                'checkOutPhoto' => [],
                'atd_segments' => [],
                'presentCount' => 0,
                'leaveCount' => 0,
                'holidayCount' => 0,
                'weekOffCount' => 0,
                'absentCount' => 0,
                'halfDayCount' => 0,
                'missedPunchCount' => 0,
                'overtimeCount' => 0,
                'lateCount' => 0,
                'earlyExitCount' => 0,
                'approvedLeaveCount' => 0,
                'approvedMissedPunchCount' => 0,
                'isApproved' => null,
                'previousCheckInTime' => null,
                'previousCheckOutTime' => null,
                'previousLate' => null,
                'previousExit' => null,
                'UPL' => 0,
            ];
            if ($employee->emp_date_of_joining <= $date) {


                $attendance_record_exit = $attendanceRecords[$date] ?? null;
                $attendance_log = $attendanceLogs[$date] ?? null;
                $missedPunch = $missedPunches[$date] ?? null;
                $holiday_record_exit = $holiday_record_exits[$date] ?? null;

                // $leave_record_exit = $leave_record_exits[$date] ?? null;
                $leave_record_exit = $leave_record_exits->get($date) ?? null;


                $is_found = null;

                if ($attendance_record_exit && $attendance_record_exit->fh_attendance_status) {

                    if ($attendance_record_exit->atd_attendance_status == 252) { //Half Day
                        $rowData['halfDayCount'] = 1;
                        $rowData['presentCount']  = 0.5;
                        $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
                        $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
                        $is_found = 1;
                    } else {
                        if (!$missedPunch) {
                            $rowData['status_id'] = $attendance_record_exit->fh_attendance_status->m_id;
                            $rowData['status_code'] = $attendance_record_exit->fh_attendance_status->m_type;
                            if ($attendance_record_exit->atd_attendance_status == 251) {
                                $rowData['presentCount'] = 1; //Present
                            }
                        }
                        $is_found = 1;
                    }

                    if ($attendance_record_exit->atd_is_overtime == 1) {
                        $rowData['overtimeCount'] = 1;
                    }

                    if ($attendance_record_exit->atd_is_late == 1) {
                        $rowData['lateCount'] = 1;
                    }

                    if ($attendance_record_exit->atd_is_early_exit == 1) {
                        $rowData['earlyExitCount'] = 1;
                    }

                    $rowData['status'] = $attendance_record_exit->fh_attendance_status->m_name;
                    $rowData['statusColor'] = json_decode($attendance_record_exit->fh_attendance_status->m_other, true)['color'];
                    $rowData['checkInTime'] = $attendance_record_exit->atd_check_in_time ? Carbon::parse($attendance_record_exit->atd_check_in_time)->format('H:i') : '-';
                    $rowData['checkOutTime'] = $attendance_record_exit->atd_check_out_time ? Carbon::parse($attendance_record_exit->atd_check_out_time)->format('H:i') :  '-';
                    $rowData['workingHour'] = $attendance_record_exit->atd_total_worked_hours ? number_format($attendance_record_exit->atd_total_worked_hours, 2) : '-';
                    $rowData['earlyExit'] = ($attendance_record_exit->atd_is_early_exit && $attendance_record_exit->atd_early_exit_duration) ? number_format($attendance_record_exit->atd_early_exit_duration, 2) :  null;
                    $rowData['late'] = ($attendance_record_exit->atd_is_late && $attendance_record_exit->atd_late_duration) ? number_format($attendance_record_exit->atd_late_duration, 2) :  null;
                    $rowData['OT'] = ($attendance_record_exit->atd_is_overtime && $attendance_record_exit->atd_overtime_hours) ? number_format($attendance_record_exit->atd_overtime_hours, 2) :  null;
                    $rowData['attendance_remark'] = $attendance_record_exit->atd_remark  ? $attendance_record_exit->atd_remark :  '-';
                    $rowData['checkInLocation'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_location ? $attendance_record_exit->atd_punchin_location : '--';
                    $rowData['checkOutLocation'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_location ? $attendance_record_exit->atd_punchout_location : '--';
                    $rowData['checkInPhoto'] = $attendance_record_exit && $attendance_record_exit->atd_punchin_photo ? json_decode($attendance_record_exit->atd_punchin_photo) : [];
                    $rowData['checkOutPhoto'] =  $attendance_record_exit && $attendance_record_exit->atd_punchout_photo ? json_decode($attendance_record_exit->atd_punchout_photo) : [];
                    $rowData['atd_segments'] =  $attendance_record_exit && $attendance_record_exit->atd_segments ? [json_decode($attendance_record_exit->atd_segments)] : [];
                    $rowData['updatedBy'] = $attendance_record_exit->updated_by  ? $attendance_record_exit->updated_by->emp_full_name :  '-';
                    if ($attendance_log) {
                        $rowData['previousCheckInTime'] = $attendance_log->al_check_in_time ? Carbon::parse($attendance_log->al_check_in_time)->format('H:i') : '-';
                        $rowData['previousCheckOutTime'] = $attendance_log->al_check_out_time ? Carbon::parse($attendance_log->al_check_out_time)->format('H:i') :  '-';
                        $rowData['previousLate'] = ($attendance_log->al_is_late && $attendance_log->al_late_duration) ? number_format($attendance_log->al_late_duration, 2) : null;
                        $rowData['previousExit'] = ($attendance_log->al_is_early_exit && $attendance_log->al_early_exit_duration) ? number_format($attendance_log->al_early_exit_duration, 2) : null;
                    }
                }

                $half_day_present = ($attendance_record_exit && $attendance_record_exit->atd_attendance_status == 252); // 252 == Half Day

                if (is_null($is_found) || $half_day_present) {
                    if ($leave_record_exit && $leave_record_exit->count() == 1) {
                        $lvr_exit = $leave_record_exit->first();

                        $is_approved = $lvr_exit->lvr_status != 170 && $lvr_exit->lvr_stage_completed;
                        $is_unpaid = $lvr_exit->fh_leave_cat_type->m_id == 215;
                        $is_half_day_leave = $lvr_exit->fh_leave_day_type->m_id != 201;
                        $segment_id = $lvr_exit->fh_leave_day_segment->m_id ?? null;

                        $leave_category_ids = MasterTable::where('m_group', 'LEAVE_CATEGORY')->pluck('m_id')->toArray();

                        // Default leave count
                        $rowData['leaveCount'] = $is_half_day_leave ? 0.5 : 1;
                        $rowData['approvedLeaveCount'] = ($is_approved && !$is_unpaid) ? $rowData['leaveCount'] : 0;
                        $rowData['isApproved'] = $is_approved;

                        if (in_array($lvr_exit->fh_leave_cat_type->m_id, $leave_category_ids) && $is_approved) {
                            $is_found = 1;

                            // ✅ Case: Half-day present + Half-day leave
                            if ($half_day_present && $is_half_day_leave) {
                                $presentStatus = $attendance_record_exit->fh_attendance_status;

                                if ($segment_id == 236) { // 2nd Half Leave
                                    $rowData['status_id'] = $presentStatus->m_id . '/' . $lvr_exit->fh_leave_cat_type->m_id;
                                    $rowData['status'] = $presentStatus->m_name . '/' . $lvr_exit->fh_leave_cat_type->m_name;
                                    $rowData['status_code'] = $presentStatus->m_type . '/' . $lvr_exit->fh_leave_cat_type->m_type;
                                    $rowData['statusColor'] = json_decode($presentStatus->m_other, true)['color'] . '/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
                                } elseif ($segment_id == 235) { // 1st Half Leave
                                    $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $presentStatus->m_id;
                                    $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $presentStatus->m_name;
                                    $rowData['status_code'] = $lvr_exit->fh_leave_cat_type->m_type . '/' . $presentStatus->m_type;
                                    $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($presentStatus->m_other, true)['color'];
                                }

                                // Counts
                                $rowData['presentCount'] = $is_unpaid ? 0.5 : 1;
                                $rowData['leaveCount'] = 0.5;
                                $rowData['approvedLeaveCount'] = $is_unpaid ? 0 : 0.5;
                            }

                            // ✅ Case: SL/UPL or CL/UPL (0.5 count only)
                            elseif ($lvr_exit->lvr_total_leave_days == 0.5 && Carbon::parse($date)->format('Y-m-d') < now()->format('Y-m-d')) {
                                $upLeave = MasterTable::where('m_id', 215)->first();

                                $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $upLeave?->m_id;
                                $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $upLeave?->m_name;
                                $rowData['status_code'] = $lvr_exit->fh_leave_cat_type->m_type . '/' . $upLeave?->m_type;
                                $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($upLeave->m_other, true)['color'];

                                $rowData['presentCount'] = 0.5;
                                $rowData['leaveCount'] = 1;
                                $rowData['approvedLeaveCount'] = !$is_unpaid ? 0.5 : 0;
                            }

                            // ✅ Case: Only single full/half leave (no half-day present)
                            elseif (!$half_day_present) {
                                $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id;
                                $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name;
                                $rowData['status_code'] = $lvr_exit->fh_leave_cat_type->m_type;
                                $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];

                                $rowData['presentCount'] = $is_unpaid ? 0 : $rowData['leaveCount'];
                            }
                        }
                    }

                    // ✅ Case: Two half-day leaves like CL/SL or CL/UPL etc.
                    elseif ($leave_record_exit && $leave_record_exit->count() == 2) {
                        $leaves = $leave_record_exit->sortBy(function ($l) {
                            return optional($l->fh_leave_day_segment)->m_id ?? 0; // fallback to 0 if null
                        })->values();

                        $l1 = $leaves[0];
                        $l2 = $leaves[1];



                        $is_approved1 = $l1->lvr_status != 170 && $l1->lvr_stage_completed;
                        $is_approved2 = $l2->lvr_status != 170 && $l2->lvr_stage_completed;

                        if ($is_approved1 || $is_approved2) {
                            $rowData['status_id'] = $l1->fh_leave_cat_type->m_id . '/' . $l2->fh_leave_cat_type->m_id;
                            $rowData['status'] = $l1->fh_leave_cat_type->m_name . '/' . $l2->fh_leave_cat_type->m_name;
                            $rowData['status_code'] = $l1->fh_leave_cat_type->m_type . '/' . $l2->fh_leave_cat_type->m_type;
                            $rowData['statusColor'] = json_decode($l1->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($l2->fh_leave_cat_type->m_other, true)['color'];

                            $is_found = 1;
                            $rowData['leaveCount'] = 1;
                            $rowData['approvedLeaveCount'] = 0;
                            $rowData['presentCount'] = 0;

                            if ($is_approved1 && $l1->fh_leave_cat_type->m_id != 215) {
                                $rowData['presentCount'] += 0.5;
                                $rowData['approvedLeaveCount'] += 0.5;
                            }

                            if ($is_approved2 && $l2->fh_leave_cat_type->m_id != 215) {
                                $rowData['presentCount'] += 0.5;
                                $rowData['approvedLeaveCount'] += 0.5;
                            }

                            $rowData['isApproved'] = $is_approved1 && $is_approved2;
                        }
                    }
                }

                $attendance_exist = $attendance_record_exit && ($attendance_record_exit->atd_check_in_time || $attendance_record_exit->atd_check_out_time);

                if (is_null($is_found) || $attendance_exist) {
                    if ($missedPunch) {
                        $missedPunchStatus = MasterTable::where('m_id', 228)->first(); //Missedpunch
                        $is_found = 1;
                        $rowData['missedPunchCount'] =  1;
                        $rowData['checkInTime'] = Carbon::createFromFormat('H:i:s', $missedPunch->ae_in_time)->format('h:i A');
                        $rowData['checkOutTime'] =  Carbon::createFromFormat('H:i:s', $missedPunch->ae_out_time)->format('h:i A');
                        $rowData['workingHour'] = number_format($missedPunch->ae_total_working, 2);
                        if ($missedPunch->ae_status != 170 && $missedPunch->ae_stage_completed) {
                            $shiftStartTime = date('Y-m-d', strtotime($date)) . ' ' . $employee->fh_shift_type->pst_start_time ?? '09:00:00';;
                            $shiftEndTime = date('Y-m-d', strtotime($date)) . ' ' . $employee->fh_shift_type->pst_end_time ?? '18:00:00';

                            $pst_start_time = Carbon::parse($shiftStartTime);
                            $pst_end_time = Carbon::parse($shiftEndTime);
                            $dailyWorkingHours = $pst_start_time->diffInMinutes($pst_end_time);

                            $checkInTime = Carbon::parse($date . ' ' . $missedPunch->ae_in_time);
                            $checkOutTime =  Carbon::parse($date . ' ' . $missedPunch->ae_out_time);
                            $workedDuration = $checkInTime->diffInMinutes($checkOutTime);
                            $fullDayThreshold = $dailyWorkingHours;
                            $halfDayThreshold = $dailyWorkingHours / 2;
                            if ($workedDuration >= $fullDayThreshold) {
                                $rowData['presentCount']  = 1; //if missed punch  approved count as present
                                $presentData = MasterTable::where('m_id', 251)->select('m_id', 'm_name', 'm_type', 'm_other')->first();
                                $rowData['status_id'] = $presentData->m_id;
                                $rowData['status'] = $presentData->m_name;
                                $rowData['status_code'] = $presentData->m_type;
                                $rowData['statusColor'] = json_decode($presentData->m_other, true)['color'];
                                $rowData['approvedMissedPunchCount'] = 0.5;
                            } else if ($workedDuration >= $halfDayThreshold) { //half day present & half day leave case
                                $halfDayPresentData = MasterTable::where('m_id', 252)->select('m_id', 'm_name', 'm_type', 'm_other')->first();
                                if ($leave_record_exit && $leave_record_exit->count() == 1) {
                                    $lvr_exit = $leave_record_exit->first();
                                    if (optional($lvr_exit->fh_leave_day_segment)->m_id == 236) {
                                        $rowData['status_id'] = $halfDayPresentData->m_id . '/' . $lvr_exit->fh_leave_cat_type->m_id;
                                        $rowData['status'] = $halfDayPresentData->m_name . '/' . $lvr_exit->fh_leave_cat_type->m_name;
                                        $rowData['status_code'] = $halfDayPresentData->m_type . '/' . $lvr_exit->fh_leave_cat_type->m_type;
                                        $rowData['statusColor'] = json_decode($halfDayPresentData->m_other, true)['color'] . '/' . json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'];
                                    } elseif (optional($lvr_exit->fh_leave_day_segment)->m_id == 235) {
                                        $rowData['status_id'] = $lvr_exit->fh_leave_cat_type->m_id . '/' . $halfDayPresentData->m_id;
                                        $rowData['status'] = $lvr_exit->fh_leave_cat_type->m_name . '/' . $halfDayPresentData->m_name;
                                        $rowData['status_code'] =  $lvr_exit->fh_leave_cat_type->m_type . '/' . $halfDayPresentData->m_type;
                                        $rowData['statusColor'] = json_decode($lvr_exit->fh_leave_cat_type->m_other, true)['color'] . '/' . json_decode($halfDayPresentData->m_other, true)['color'];
                                    }
                                }
                            }
                        } else {
                            $rowData['status_id'] = $missedPunchStatus->m_id;
                            $rowData['status'] =   $missedPunchStatus->m_name;
                            $rowData['status_code'] = $missedPunchStatus->m_type;
                            $rowData['statusColor'] = json_decode($missedPunchStatus->m_other, true)['color'];
                        }
                    }
                }

                if (is_null($is_found)) {


                    if ($holiday_record_exit) {
                        $holidayStatus = MasterTable::where('m_id', 321)->first();
                        $rowData['holidayCount'] = 1;
                        $is_found = 1;
                        $rowData['status'] = $holidayStatus->m_name;
                        $rowData['status_id'] = $holidayStatus->m_id;
                        $rowData['status_code'] = $holidayStatus->m_type;
                        $rowData['statusColor'] = json_decode($holidayStatus->m_other, true)['color'];
                        $rowData['checkInTime'] = '-';
                        $rowData['checkOutTime'] = '-';
                        $rowData['workingHour'] = '-';
                    }
                }
                if (is_null($is_found)) {

                    if (in_array($date, $weekOfDates)) {
                        $weekOffStatus = MasterTable::where('m_id', 322)->first();
                        $rowData['weekOffCount'] = 1;
                        $is_found = 1;
                        $rowData['status'] = $weekOffStatus->m_name;
                        $rowData['status_id'] = $weekOffStatus->m_id;
                        $rowData['status_code'] = $weekOffStatus->m_type;
                        $rowData['statusColor'] = json_decode($weekOffStatus->m_other, true)['color'];
                        $rowData['checkInTime'] = '-';
                        $rowData['checkOutTime'] = '-';
                        $rowData['workingHour'] = '-';
                    }
                }
                if (is_null($is_found) && Carbon::parse($date)->isPast()) {
                    $rowData['absentCount'] = 1;
                    $rowData['status'] = $absentStatus->m_name;
                    $rowData['status_id'] = $absentStatus->m_id;
                    $rowData['status_code'] = $absentStatus->m_type;
                    $rowData['statusColor'] = json_decode($absentStatus->m_other, true)['color'];
                    $rowData['checkInTime'] = '-';
                    $rowData['checkOutTime'] = '-';
                    $rowData['workingHour'] = '-';
                }
                if ($rowData['status_id']) {
                    $rowData['status_id'] = (string)$rowData['status_id'];
                }
                $rowData['date'] = $date;
                $attendanceData[] = $rowData;
            }
        }
        return $attendanceData;
    }


    public static function sendemailcandidate($candidateTemplate, array $candidatePlaceholders, $candidate, $businessId, $attachment = null)
    {
        if (!$candidateTemplate) return false;

        $mailBody = str_replace(array_keys($candidatePlaceholders), array_values($candidatePlaceholders), $candidateTemplate->mt_body);
        $mailSubject = str_replace(array_keys($candidatePlaceholders), array_values($candidatePlaceholders), $candidateTemplate->mt_title);

        try {
            Mail::send([], [], function ($message) use ($candidate, $mailSubject, $mailBody, $attachment) {
                $message->to($candidate)
                    ->subject($mailSubject)
                    ->html($mailBody);
                if ($attachment) {
                    $message->attach($attachment['path'], [
                        'as' => $attachment['name'],
                        'mime' => $attachment['mime'],
                    ]);
                }
            });
        } catch (\Exception $e) {
            \Log::error("Candidate Email Sending Failed: " . $e->getMessage());
            return false;
        }

        return true;
    }



    public static function sendemailinteviver($interviewerTemplate, array $interviewerPlaceholders, $manager_email, $businessId, $attachment = null)
    {
        if (!$interviewerTemplate) return false;

        $mailBody = str_replace(array_keys($interviewerPlaceholders), array_values($interviewerPlaceholders), $interviewerTemplate->mt_body);
        $mailSubject = str_replace(array_keys($interviewerPlaceholders), array_values($interviewerPlaceholders), $interviewerTemplate->mt_title);

        try {
            Mail::send([], [], function ($message) use ($manager_email, $mailSubject, $mailBody, $attachment) {
                $message->to($manager_email)
                    ->subject($mailSubject)
                    ->html($mailBody);
                if ($attachment) {
                    $message->attach($attachment['path'], [
                        'as' => $attachment['name'],
                        'mime' => $attachment['mime'],
                    ]);
                }
            });
        } catch (\Exception $e) {
            \Log::error("Candidate Email Sending Failed: " . $e->getMessage());
            return false;
        }

        return true;
    }
}
